#include "SharedInterfaces.h"
#include "25i-6601_Helper.h"
#include<iostream>
#include<ctime>

Contest::Contest()
{
    timerSeconds = 0;
    startTimestamp = 0;
    score = 0;
    isActive = false;
    owner = nullptr;
}

Contest::Contest(AppUser* user, int durationSeconds, const MyString& savePath)
{
    owner = user;
    timerSeconds = durationSeconds;
    startTimestamp = 0;
    score = 0;
    isActive = false;
    vfsSavePath = savePath;
}

void Contest::start(ProblemBank& bank)
{
    buildProblemSet(bank);
    startTimestamp = (int)time(nullptr);   // this returns the time, we use tyepcasting because it returns time_t 
    isActive = true;
}

Verdict Contest::submit(const char* code, int problemId, int attempt)
{
    // how many seconds since contest started
    int timeTaken = (int)time(nullptr) - startTimestamp;

    // create submission record
    Submission* s = new Submission(code, problemId, attempt, timeTaken);

    // find the problem from problemSet
    Problem* p = nullptr;
    for (int i = 0; i < problemSet.size(); i++)
    {
        if (problemSet.get(i)->getId() == problemId)
        {
            p = problemSet.get(i);
            break;
        }
    }

    if (p == nullptr)
    {
        s->setVerdict(WRONG_ANSWER);
        submissions.push(s);
        return WRONG_ANSWER;
    }

    // evaluate
    Judge judge;
    Verdict v = judge.evaluate(s, p);
    s->setVerdict(v);

    // store submission
    submissions.push(s);

    return v;
}

int Contest::getTimeRemaining() const
{
    int timeGone = (int)time(nullptr) - startTimestamp;
    return timerSeconds - timeGone;
}

int Contest::getScore() const
{
    return score;
}

bool Contest::getIsActive() const
{
    return isActive;
}

DynamicArray<Submission*>& Contest::getSubmissions()
{
    return submissions;
}

int Contest::calcScore()
{
    score = 0;  // reset before calculating
    for (int i = 0; i < submissions.size(); i++)
    {
        Submission* s = submissions.get(i);
        if (s->getVerdict() == ACCEPTED)
        {
            score += 100;
            score -= (s->getAttempt() - 1) * 10; 
            score -= (s->getTimeTaken() / 60);
        }
    }
    return score;
}

void Contest::saveProgress(VFSAdapter& vfs)
{
    char buf[32];
    intToStr(startTimestamp, buf);
    vfs.writeFile(vfsSavePath + MyString("timer.txt"), MyString(buf));

    intToStr(timerSeconds, buf);
    vfs.writeFile(vfsSavePath + MyString("duration.txt"), MyString(buf));

    intToStr(score, buf);
    vfs.writeFile(vfsSavePath + MyString("score.txt"), MyString(buf));

    intToStr(isActive, buf);
    vfs.writeFile(vfsSavePath + MyString("active.txt"), MyString(buf));
}

void Contest::loadProgress(VFSAdapter& vfs)
{
    startTimestamp = strToInt(vfs.readFile(vfsSavePath + MyString("timer.txt")).c_str());
    timerSeconds = strToInt(vfs.readFile(vfsSavePath + MyString("duration.txt")).c_str());
    score = strToInt(vfs.readFile(vfsSavePath + MyString("score.txt")).c_str());
    isActive = strToInt(vfs.readFile(vfsSavePath + MyString("active.txt")).c_str());
}

void Contest::endContest(VFSAdapter& vfs)
{
    isActive = false;
    calcScore();
    saveProgress(vfs);
}

Contest::~Contest()
{
    for (int i = 0; i < submissions.size(); i++)
        delete submissions.get(i);
}

void Contest::serialize(const char* path) {
    // saves contest state to VFS - stub for now
}
void Contest::deserialize(const char* path) {
    // loads contest state from VFS - stub for now
}
