#include "25i-6601_Directory.h"
#include "25i-6601_File.h"
#include "25i-6601_SymbolicLink.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
Directory::Directory() : FSEntity()
{
    children =nullptr;
    childCount = 0;
    parent = nullptr;
}

// Parameterized constructor
Directory::Directory(const char* n, const char* created, User* o, Directory* p)
: FSEntity(n, created, o, DIRECTORY_TYPE)
{
    parent = p;
    children = nullptr;
    childCount = 0;
}

// Destructor
// we Do not delete parent because we dont own it
Directory::~Directory()
{
    for(int i=0; i<childCount; i++)
    {
        delete children[i];
    }

    delete[] children;
}

// Adds a new child FSEntity pointer to the children array
void Directory::addChild(FSEntity* entity)
{
    FSEntity** newChild = new FSEntity*[childCount+1];

    int i;
    for(i=0; i< childCount; i++)
    {
        newChild[i] = children[i];
    }

    newChild[childCount] = entity;

    delete[] children;

    children = newChild;

    childCount++;
}

// Removes a child by name, deletes it, and shrinks the array
void Directory::removeChild(const char* n)
{
    //  find the index of the child to remove
    int index = -1;
    for(int i = 0; i < childCount; i++)
    {
        if(strcmp(children[i]->name, n) == 0)
        {
            index = i;
            break;
        }
    }

   
    if(index == -1)
    {
        cout << "Child not found\n";
        return;
    }

    delete children[index];

    // shift everything after index one step left
    for(int i = index; i < childCount - 1; i++)
    {
        children[i] = children[i + 1];
    }

    FSEntity** newArr = new FSEntity*[childCount - 1];
    for(int i = 0; i < childCount - 1; i++)
    {
        newArr[i] = children[i];
    }

    delete[] children;
    children = newArr;
    childCount--;
}


FSEntity* Directory::findChild(const char* n)
{
    for(int i=0; i<childCount; i++)
    {
        if(strcmp(children[i]->name, n) == 0)
        {
            return children[i];
        }
    }

    return nullptr;
}

// Prints only the direct children of this directory
void Directory::listShallow()
{
    for(int i = 0; i < childCount; i++)
    {
        cout << "Name: " << children[i]->name;
        cout << " | Size: " << children[i]->getSize();
        if(children[i]->owner != nullptr)
            cout << " | Owner: " << children[i]->owner->username;
        cout << endl;
    }
}

void Directory::listDeep(int depth)
{

}

FSEntity* Directory::search(const char* pattern)
{
    if(pattern == nullptr) return nullptr;
    for(int i = 0; i < childCount; i++)
    {
        if(strcmp(children[i]->name, pattern) == 0)
            return children[i];
    }
    for(int i = 0; i < childCount; i++)
    {
        Directory* d = dynamic_cast<Directory*>(children[i]);
        if(d)
        {
            FSEntity* found = d->search(pattern);
            if(found) return found;
        }
    }
    return nullptr;
}

//computes total size of all File objects in this subtree
int Directory::computeSize()
{
    int total = 0;
    for(int i = 0; i < childCount; i++)
    {
        total += children[i]->getSize();
    }
    return total;
}

// Prints directory info including child count and total size
void Directory::display()
{
    displayInfo();
    cout<<"Child count: "<<childCount<<endl;
    cout<<"Total size: "<< computeSize();
}

// Returns total size of this directory's subtree
int Directory::getSize()
{
    return computeSize();
}