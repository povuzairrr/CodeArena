#ifndef FILE_H
#define FILE_H

#include "25i-6601_FSEntity.h"
#include "25i-6601_VersionRecord.h"

class File : public FSEntity {
public:
    char* content;                  
    int size;                       
    VersionRecord* versionHistory;  
    int versionCount;               

    File();
    File(const char* n, const char* created, User* o, const char* fileContent);
    ~File();

    void setContent(const char* newContent, User* editedBy); 
    void displayHistory();                                   

    void display();                 
    int getSize();                  
};

#endif