#ifndef PERMISSION_H
#define PERMISSION_H

class Permission {
public:
    bool ownerRead, ownerWrite, ownerExecute;
    bool groupRead, groupWrite, groupExecute;
    bool othersRead, othersWrite, othersExecute;

    Permission();

    void setOwner(bool r, bool w, bool x);
    void setGroup(bool r, bool w, bool x);
    void setOthers(bool r, bool w, bool x);

    bool canOwnerRead();
    bool canOwnerWrite();
    bool canOwnerExecute();

    bool canGroupRead();
    bool canGroupWrite();
    bool canGroupExecute();

    bool canOthersRead();
    bool canOthersWrite();
    bool canOthersExecute();

    void display(); // prints rwxr-x---
};

#endif