#include "SharedInterfaces.h"
#include <cstdio>

// ─── helpers ────────────────────────────────────────────────

static MyString intToMyStr(int n) {
    char buf[32];
    sprintf(buf, "%d", n);
    return MyString(buf);
}

static int myStrToInt(const MyString& s) {
    int result = 0;
    const char* p = s.c_str();
    bool neg = false;
    if (*p == '-') { neg = true; p++; }
    while (*p >= '0' && *p <= '9') {
        result = result * 10 + (*p - '0');
        p++;
    }
    return neg ? -result : result;
}

// Returns the Nth line (0-indexed) from a MyString, split by '\n'
static MyString getLine(const MyString& text, int lineIndex) {
    const char* s = text.c_str();
    int curLine = 0, i = 0;
    while (s[i] != '\0') {
        if (curLine == lineIndex) {
            int start = i;
            while (s[i] != '\0' && s[i] != '\n') i++;
            int len = i - start;
            char* buf = new char[len + 1];
            for (int j = 0; j < len; j++) buf[j] = s[start + j];
            buf[len] = '\0';
            MyString result(buf);
            delete[] buf;
            return result;
        }
        if (s[i] == '\n') curLine++;
        i++;
    }
    return MyString("");
}

// ─── Problem ────────────────────────────────────────────────

Problem::Problem()
    : id(0), difficulty(1) {}

Problem::Problem(int id, const char* title, const char* desc, int difficulty)
    : id(id), title(title), description(desc), difficulty(difficulty) {}

void Problem::addTestCase(const TestCase& tc) {
    testCases.push(tc);
}

int      Problem::getId()          const { return id; }
MyString Problem::getTitle()       const { return title; }
MyString Problem::getDescription() const { return description; }
int      Problem::getDifficulty()  const { return difficulty; }

DynamicArray<TestCase>& Problem::getTestCases() {
    return testCases;
}

// Format: id / difficulty / title / description / tc_count / input / expected / ...
void Problem::serialize(const char* path) {
    MyString content = intToMyStr(id)              + MyString("\n")
                     + intToMyStr(difficulty)      + MyString("\n")
                     + title                       + MyString("\n")
                     + description                 + MyString("\n")
                     + intToMyStr(testCases.size())+ MyString("\n");

    for (int i = 0; i < testCases.size(); i++) {
        content = content + testCases.get(i).getInput()    + MyString("\n");
        content = content + testCases.get(i).getExpected() + MyString("\n");
    }

    VFSAdapter vfs;
    vfs.writeFile(MyString(path), content);
}

void Problem::deserialize(const char* path) {
    VFSAdapter vfs;
    MyString content = vfs.readFile(MyString(path));

    id          = myStrToInt(getLine(content, 0));
    difficulty  = myStrToInt(getLine(content, 1));
    title       = getLine(content, 2);
    description = getLine(content, 3);
    int tcCount = myStrToInt(getLine(content, 4));

    testCases.clear();
    for (int i = 0; i < tcCount; i++) {
        int base = 5 + i * 2;
        testCases.push(TestCase(
            getLine(content, base).c_str(),
            getLine(content, base + 1).c_str()
        ));
    }
}
