#include "SharedInterfaces.h"
#include <cstdio>
#include <ctime>

// Static instance — created on first call to getInstance()
ProblemBank* ProblemBank::instance = nullptr;

ProblemBank::ProblemBank() {}

ProblemBank* ProblemBank::getInstance() {
    if (instance == nullptr)
        instance = new ProblemBank();
    return instance;
}

// ─── seed ───────────────────────────────────────────────────
// 15 problems: 5 easy, 5 medium, 5 hard. 3 test cases each.

void ProblemBank::seedProblems() {
    if (problems.size() > 0) return;  // already seeded

    // ── EASY ────────────────────────────────────────────────

    Problem* p1 = new Problem(1, "Sum of Two Numbers",
        "Given two integers a and b on one line, print their sum.", EASY);
    p1->addTestCase(TestCase("1 2",   "3"));
    p1->addTestCase(TestCase("0 0",   "0"));
    p1->addTestCase(TestCase("-3 7",  "4"));
    problems.push(p1);

    Problem* p2 = new Problem(2, "Even or Odd",
        "Given an integer n, print EVEN if even, ODD otherwise.", EASY);
    p2->addTestCase(TestCase("4", "EVEN"));
    p2->addTestCase(TestCase("7", "ODD"));
    p2->addTestCase(TestCase("0", "EVEN"));
    problems.push(p2);

    Problem* p3 = new Problem(3, "Max of Three",
        "Given three integers on one line, print the largest.", EASY);
    p3->addTestCase(TestCase("3 7 2",    "7"));
    p3->addTestCase(TestCase("-1 -5 0",  "0"));
    p3->addTestCase(TestCase("4 4 4",    "4"));
    problems.push(p3);

    Problem* p4 = new Problem(4, "Reverse a Number",
        "Given a non-negative integer, print it with digits reversed.", EASY);
    p4->addTestCase(TestCase("1234", "4321"));
    p4->addTestCase(TestCase("100",  "1"));
    p4->addTestCase(TestCase("7",    "7"));
    problems.push(p4);

    Problem* p5 = new Problem(5, "Factorial",
        "Given n (0 <= n <= 12), print n!.", EASY);
    p5->addTestCase(TestCase("0",  "1"));
    p5->addTestCase(TestCase("5",  "120"));
    p5->addTestCase(TestCase("10", "3628800"));
    problems.push(p5);

    // ── MEDIUM ──────────────────────────────────────────────

    Problem* p6 = new Problem(6, "Prime Check",
        "Given an integer n >= 2, print YES if prime, NO otherwise.", MEDIUM);
    p6->addTestCase(TestCase("2",  "YES"));
    p6->addTestCase(TestCase("9",  "NO"));
    p6->addTestCase(TestCase("97", "YES"));
    problems.push(p6);

    Problem* p7 = new Problem(7, "GCD of Two Numbers",
        "Given two positive integers, print their GCD.", MEDIUM);
    p7->addTestCase(TestCase("12 8",   "4"));
    p7->addTestCase(TestCase("100 75", "25"));
    p7->addTestCase(TestCase("7 13",   "1"));
    problems.push(p7);

    Problem* p8 = new Problem(8, "Count Vowels",
        "Given a lowercase string (no spaces), print the number of vowels.", MEDIUM);
    p8->addTestCase(TestCase("hello",  "2"));
    p8->addTestCase(TestCase("aeiou",  "5"));
    p8->addTestCase(TestCase("rhythm", "0"));
    problems.push(p8);

    Problem* p9 = new Problem(9, "Fibonacci Nth Term",
        "Given n (1-indexed), print the nth Fibonacci number. F(1)=1, F(2)=1.", MEDIUM);
    p9->addTestCase(TestCase("1",  "1"));
    p9->addTestCase(TestCase("7",  "13"));
    p9->addTestCase(TestCase("10", "55"));
    problems.push(p9);

    Problem* p10 = new Problem(10, "Power of Two",
        "Given a positive integer n, print YES if it is a power of 2, NO otherwise.", MEDIUM);
    p10->addTestCase(TestCase("1",  "YES"));
    p10->addTestCase(TestCase("16", "YES"));
    p10->addTestCase(TestCase("18", "NO"));
    problems.push(p10);

    // ── HARD ────────────────────────────────────────────────

    Problem* p11 = new Problem(11, "Longest Common Subsequence",
        "Two strings on separate lines. Print the length of their LCS.", HARD);
    p11->addTestCase(TestCase("abcde\nace",  "3"));
    p11->addTestCase(TestCase("abc\nabc",    "3"));
    p11->addTestCase(TestCase("abc\ndef",    "0"));
    problems.push(p11);

    Problem* p12 = new Problem(12, "0-1 Knapsack",
        "First line: N W. Next N lines: weight value. Print max value.", HARD);
    p12->addTestCase(TestCase("3 50\n10 60\n20 100\n30 120", "220"));
    p12->addTestCase(TestCase("1 1\n2 10",                    "0"));
    p12->addTestCase(TestCase("2 10\n5 40\n10 60",            "60"));
    problems.push(p12);

    Problem* p13 = new Problem(13, "Matrix Chain Multiplication",
        "First line: N. Second line: N+1 dimensions. Print min scalar multiplications.", HARD);
    p13->addTestCase(TestCase("4\n40 20 30 10 30", "26000"));
    p13->addTestCase(TestCase("2\n10 100 5",        "5000"));
    p13->addTestCase(TestCase("1\n5 10",            "0"));
    problems.push(p13);

    Problem* p14 = new Problem(14, "Coin Change (Min Coins)",
        "Line 1: N coins. Line 2: coin values. Line 3: target. Print min coins or -1.", HARD);
    p14->addTestCase(TestCase("3\n1 5 6\n11", "2"));
    p14->addTestCase(TestCase("2\n2 5\n3",    "-1"));
    p14->addTestCase(TestCase("1\n1\n10",     "10"));
    problems.push(p14);

    Problem* p15 = new Problem(15, "Edit Distance",
        "Two strings on separate lines. Print the minimum edit distance.", HARD);
    p15->addTestCase(TestCase("kitten\nsitting", "3"));
    p15->addTestCase(TestCase("abc\nabc",        "0"));
    p15->addTestCase(TestCase("a\nb",            "1"));
    problems.push(p15);
}

// ─── VFS load ───────────────────────────────────────────────

void ProblemBank::loadFromVFS(VFSAdapter& vfs) {
    for (int i = 1; i <= 15; i++) {
        char buf[64];
        sprintf(buf, "/problems/%d.txt", i);
        if (vfs.exists(MyString(buf))) {
            Problem* p = new Problem();
            p->deserialize(buf);
            problems.push(p);
        }
    }
    // First run — seed and persist
    if (problems.size() == 0) {
        seedProblems();
        for (int i = 0; i < problems.size(); i++) {
            char buf[64];
            sprintf(buf, "/problems/%d.txt", problems.get(i)->getId());
            problems.get(i)->serialize(buf);
        }
    }
}

// ─── queries ────────────────────────────────────────────────

DynamicArray<Problem*> ProblemBank::getByDifficulty(int level) {
    DynamicArray<Problem*> result;
    for (int i = 0; i < problems.size(); i++)
        if (problems.get(i)->getDifficulty() == level)
            result.push(problems.get(i));
    return result;
}

// Fisher-Yates shuffle on the filtered pool, then take `count` problems
DynamicArray<Problem*> ProblemBank::getRandom(int count, int level) {
    DynamicArray<Problem*> pool = getByDifficulty(level);

    unsigned int seed = (unsigned int)time(nullptr);
    for (int i = pool.size() - 1; i > 0; i--) {
        seed = seed * 1664525u + 1013904223u;
        int j = seed % (i + 1);
        Problem* tmp = pool.get(i);
        pool.get(i)  = pool.get(j);
        pool.get(j)  = tmp;
    }

    DynamicArray<Problem*> result;
    int take = count < pool.size() ? count : pool.size();
    for (int i = 0; i < take; i++)
        result.push(pool.get(i));
    return result;
}

Problem* ProblemBank::getById(int id) {
    for (int i = 0; i < problems.size(); i++)
        if (problems.get(i)->getId() == id)
            return problems.get(i);
    return nullptr;
}

ProblemBank::~ProblemBank() {
    for (int i = 0; i < problems.size(); i++)
        delete problems.get(i);
}
