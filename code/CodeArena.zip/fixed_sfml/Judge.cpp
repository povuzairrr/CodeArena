#include "SharedInterfaces.h"
#include<iostream>
using namespace std;

Judge::Judge()
{
    tempDir = "";
}

bool Judge::compile(const MyString& srcPath, const MyString& binPath)
{
    char command[512];
    strcpy(command, "g++ ");
    strcat(command, srcPath.c_str());
    strcat(command, " -o ");
    strcat(command, binPath.c_str());
    int result = system(command);
    return result == 0;
}

MyString Judge::injectTemplate(const MyString& userCode)
{
    const char* src = userCode.c_str();
    // Check if user already has #include to avoid double injection
    for (int i = 0; src[i] != '\0'; i++)
    {
        if (src[i] == '#' && src[i+1] == 'i') return userCode;
    }
    MyString code;
    MyString header("#include <iostream>\nusing namespace std;\n");
    code = header + userCode;
    return code;
}

MyString Judge::runAndCapture(const MyString& binPath, const MyString& input)
{
    FILE* inputFile = fopen("temp_input.txt", "w");
    if (inputFile == nullptr) return MyString("");
    fprintf(inputFile, "%s", input.c_str());
    fclose(inputFile);

    char command[512];
    strcpy(command, "./");
    strcat(command, binPath.c_str());
    strcat(command, " < temp_input.txt > temp_output.txt 2>/dev/null");
    system(command);

    FILE* outputFile = fopen("temp_output.txt", "r");
    if (outputFile == nullptr) return MyString("");

    char buffer[4096];
    int i = 0;
    int c;
    while ((c = fgetc(outputFile)) != EOF && i < 4095)
    {
        buffer[i++] = (char)c;
    }
    buffer[i] = '\0';
    fclose(outputFile);

    // trim trailing whitespace/newlines so "3\n" matches "3"
    while (i > 0 && (buffer[i-1] == '\n' || buffer[i-1] == '\r' || buffer[i-1] == ' '))
    {
        buffer[--i] = '\0';
    }

    return MyString(buffer);
}

bool Judge::compareOutput(const MyString& got, const MyString& expected)
{
    // also trim expected in case it has trailing whitespace
    const char* e = expected.c_str();
    int elen = 0;
    while (e[elen]) elen++;
    char trimmed[4096];
    int ti = 0;
    for (int i = 0; i < elen && ti < 4094; i++) trimmed[ti++] = e[i];
    trimmed[ti] = '\0';
    while (ti > 0 && (trimmed[ti-1] == '\n' || trimmed[ti-1] == '\r' || trimmed[ti-1] == ' '))
        trimmed[--ti] = '\0';

    const char* g = got.c_str();
    int i = 0;
    while (g[i] != '\0' && trimmed[i] != '\0')
    {
        if (g[i] != trimmed[i]) return false;
        i++;
    }
    return g[i] == '\0' && trimmed[i] == '\0';
}

Verdict Judge::evaluate(Submission* s, Problem* p)
{
    MyString fullCode = injectTemplate(s->getCode());
    FILE* srcFile = fopen("temp_sol.cpp", "w");
    if (srcFile == nullptr) return COMPILE_ERROR;
    fprintf(srcFile, "%s", fullCode.c_str());
    fclose(srcFile);
    if (!compile(MyString("temp_sol.cpp"), MyString("temp_sol")))
    {
        cleanup();
        return COMPILE_ERROR;
    }

    DynamicArray<TestCase>& tests = p->getTestCases();
    for (int i = 0; i < tests.size(); i++)
    {
        MyString output = runAndCapture(MyString("temp_sol"), tests.get(i).getInput());
        if (!compareOutput(output, tests.get(i).getExpected()))
        {
            cleanup();
            return WRONG_ANSWER;
        }
    }

    cleanup();
    return ACCEPTED;
}

void Judge::cleanup()
{
    remove("temp_sol.cpp");
    remove("temp_sol");
    remove("temp_input.txt");
    remove("temp_output.txt");
}
