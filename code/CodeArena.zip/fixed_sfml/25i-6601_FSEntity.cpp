#include "25i-6601_FSEntity.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
FSEntity::FSEntity()
{
    name = new char[1];
    strcpy(name, "");

    createdAt = new char[1];
    strcpy(createdAt, "");

    lastModified = new char[1];
    strcpy(lastModified, "");

    owner = nullptr;

    attributeCount = 0;

    attributes = nullptr;

    type = FILE_TYPE;
}

// Parameterized constructor
FSEntity::FSEntity(const char* n, const char* created, User* o, int t)
{
    name = new char[strlen(n) + 1];
    strcpy(name, n);

    createdAt = new char[strlen(created) + 1];
    strcpy(createdAt, created);

    owner = o;

    type = t;

    lastModified = new char[strlen(created) + 1];
    strcpy(lastModified, createdAt);

    attributeCount = 0;

    attributes = nullptr;
}

// Destructor
// We Dont delete owner, we dont own the user
FSEntity::~FSEntity()
{
    delete[] name;
    delete[] createdAt;
    delete[] lastModified;
    delete[] attributes;
}

// Adds a new ExtendedAttribute to the attributes array
void FSEntity::addAttribute(const char* key, const char* value)
{
    ExtendedAttribute* newArr = new ExtendedAttribute[attributeCount + 1];
    
    int i;
    for(i=0; i < attributeCount; i++)
    {
        newArr[i] = attributes[i];
    }

    newArr[attributeCount] = ExtendedAttribute(key, value);

    delete[] attributes;

    attributes = newArr;
    attributeCount++;
}

void FSEntity::displayAttributes()
{
    if(attributeCount == 0)
    {
        cout<<"No attributes...\n";
        return;
    }

    for(int i=0; i < attributeCount; i++)
    {
        attributes[i].display();
    }
}

void FSEntity::displayInfo()
{
    cout << "Name: " << name << endl;
    cout << "Created: " << createdAt << endl;
    cout << "Last Modified: " << lastModified << endl;

    if(owner != nullptr)
        cout << "Owner: " << owner->username << endl;
    else
        cout << "Owner: none" << endl;

    cout << "Permissions: ";
    permission.display();
    cout << endl;
}