#include "25i-6601_Volume.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
Volume::Volume()
{
    name = new char[1];
    strcpy(name, "");

    root = nullptr;

    media = nullptr;
    mediaCount = 0;

    users = nullptr;
    userCount = 0;

    mountPoints = nullptr;
    mountPointCount = 0;
}

// Parameterized constructor
Volume::Volume(const char* n)
{
    name = new char[strlen(n) + 1];
    strcpy(name, n);

    // create the root directory, it is owned by volume, no parent
    root = new Directory("root", "2026-01-01", nullptr, nullptr);

    media = nullptr;
    mediaCount = 0;

    users = nullptr;
    userCount = 0;

    mountPoints = nullptr;
    mountPointCount = 0;
}

// Destructor
Volume::~Volume()
{
    delete[] name;

    delete root;            

    for(int i = 0; i < mediaCount; i++)
        delete media[i];
    delete[] media;

    for(int i = 0; i < userCount; i++)
        delete users[i];
    delete[] users;

    delete[] mountPoints;   // do NOT delete the mountpoints themselves, root owns them
}


void Volume::addMedium(StorageMedium* m)
{
    StorageMedium** newArr = new StorageMedium*[mediaCount + 1];

    for(int i = 0; i < mediaCount; i++)
        newArr[i] = media[i];

    newArr[mediaCount] = m;

    delete[] media;
    media = newArr;
    mediaCount++;
}

void Volume::addUser(User* u)
{
    User** newArr = new User*[userCount + 1];

    for(int i = 0; i < userCount; i++)
        newArr[i] = users[i];

    newArr[userCount] = u;

    delete[] users;
    users = newArr;
    userCount++;
}


void Volume::addMountPoint(MountPoint* mp)
{
    MountPoint** newArr = new MountPoint*[mountPointCount + 1];

    for(int i = 0; i < mountPointCount; i++)
        newArr[i] = mountPoints[i];

    newArr[mountPointCount] = mp;

    delete[] mountPoints;
    mountPoints = newArr;
    mountPointCount++;
}

// Finds a user by username, returns nullptr if not found
User* Volume::findUser(const char* username)
{
    for(int i = 0; i < userCount; i++)
    {
        if(strcmp(users[i]->username, username) == 0)
            return users[i];
    }
    return nullptr;
}


void Volume::detectDanglingLinks(Directory* dir)
{
    if(dir == nullptr)
        return;

    for(int i = 0; i < dir->childCount; i++)
    {
        FSEntity* child = dir->children[i];

        if(child->type == SYMLINK_TYPE)
        {
            SymbolicLink* link = (SymbolicLink*)child;
            if(link->isDangling())
                cout << "Dangling symlink found: " << link->name << endl;
        }
        else if(child->type == DIRECTORY_TYPE || child->type == MOUNTPOINT_TYPE)
        {
            // recurse into subdirectories
            detectDanglingLinks((Directory*)child);
        }
    }
}

// Prints volume name, all media, all users, and root directory info
void Volume::display()
{
    cout << "==============================" << endl;
    cout << "Volume: " << name << endl;
    cout << "==============================" << endl;

    cout << "\n--- Storage Media (" << mediaCount << ") ---" << endl;
    for(int i = 0; i < mediaCount; i++)
        media[i]->display();

    cout << "\n--- Users (" << userCount << ") ---" << endl;
    for(int i = 0; i < userCount; i++)
        users[i]->display();

    cout << "\n--- File System ---" << endl;
    if(root != nullptr)
        root->display();

    cout << "==============================" << endl;
}