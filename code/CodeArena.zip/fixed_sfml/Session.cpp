#include "SharedInterfaces.h"

// ─── Session ─────────────────────────────────────────────────

Session::Session() : currentUser(nullptr), loggedIn(false) {}

// Call this after verifying the password in your login flow
void Session::login(AppUser* user) {
    currentUser = user;
    loggedIn    = true;
}

// Does NOT delete the User object — just clears the session
void Session::logout() {
    currentUser = nullptr;
    loggedIn    = false;
}

AppUser* Session::getUser()  const { return currentUser; }
bool  Session::isActive() const { return loggedIn; }
