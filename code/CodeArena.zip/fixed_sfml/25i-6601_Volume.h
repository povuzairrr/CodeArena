#ifndef VOLUME_H
#define VOLUME_H

#include "25i-6601_Directory.h"
#include "25i-6601_StorageMedium.h"
#include "25i-6601_User.h"
#include "25i-6601_SymbolicLink.h"
#include "25i-6601_MountPoint.h"

class Volume {
public:
    char* name;
    Directory* root;                // the root directory of the file system
    StorageMedium** media;          // dynamic array of storage media
    int mediaCount;
    User** users;                   // dynamic array of users
    int userCount;
    MountPoint** mountPoints;       // dynamic array of mount points
    int mountPointCount;

    Volume();
    Volume(const char* n);
    ~Volume();

    void addMedium(StorageMedium* m);           
    void addUser(User* u);                      
    void addMountPoint(MountPoint* mp);         

    User* findUser(const char* username);       

    void detectDanglingLinks(Directory* dir);   
    void display();                             
};

#endif