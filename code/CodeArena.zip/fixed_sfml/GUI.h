#ifndef GUI_H
#define GUI_H

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <cmath>
#include <cstdio>
#include "SharedInterfaces.h"

// ── Screen enum ─────────────────────────────────────────────
enum Screen { SCR_LOGIN, SCR_DASHBOARD, SCR_CONTEST, SCR_RESULTS };
enum LoginTab { TAB_LOGIN, TAB_REGISTER, TAB_VERIFY };

// ── Colors ──────────────────────────────────────────────────
namespace C {
    const sf::Color BG      (10,  10,  10);
    const sf::Color SURF    (17,  17,  17);
    const sf::Color SURF2   (26,  26,  26);
    const sf::Color BORDER  (42,  42,  42);
    const sf::Color RED     (230, 57,  70);
    const sf::Color RED_DIM (193, 18,  31);
    const sf::Color RED_GLO (40,  5,   8);
    const sf::Color TEXT    (240, 240, 240);
    const sf::Color MUTED   (120, 120, 120);
    const sf::Color GREEN   (34,  197, 94);
    const sf::Color YELLOW  (234, 179, 8);
    const sf::Color TRANS   (0,   0,   0, 0);
}

// ── InputBox ────────────────────────────────────────────────
struct InputBox {
    sf::RectangleShape box;
    sf::Text           displayText;
    sf::Text           placeholderText;
    char               buf[8192];
    int                bufLen;
    bool               focused;
    bool               isPassword;
    sf::Clock          cursorClock;   // for blinking cursor
    bool               cursorVisible; // blink state
    int                cursorPos;     // insertion point (0..bufLen)

    InputBox();
    void init(const sf::Font& f, float x, float y, float w, float h, const char* ph, bool pw = false);
    void handleEvent(sf::Event& e);
    void draw(sf::RenderWindow& w);
    const char* val() const;
    void clear();
    bool empty() const;
};

// ── Button ──────────────────────────────────────────────────
struct Button {
    sf::RectangleShape box;
    sf::Text           label;
    bool               isPrimary; // red filled

    Button();
    void init(const sf::Font& f, float x, float y, float w, float h, const char* txt, bool primary = false);
    bool contains(sf::Vector2f p) const;
    void draw(sf::RenderWindow& w, bool active = false);
};

// ── Main GUI ────────────────────────────────────────────────
class GUI {
    // ── Window & font ──
    sf::RenderWindow win;
    sf::Font         font;

    // ── State ──
    Screen    scr;
    LoginTab  tab;
    AppUser*  user;
    Session   session;
    VFSAdapter vfs;

    int selectedDiff;
    int contestDiff;
    int contestOffset;  // starting index into problem pool for this level

    // ── Contest state ──
    sf::Clock  clock;
    int        timerSecs;
    int        timerElapsed;
    int        currentProb;
    bool       verdictSet;
    bool       verdictOk;
    int        solvedCount;
    int        finalScore;
    int        wrongAttempts[3];
    bool       probSolved[3];
    int        totalContests;
    int        bestScore;
    int        totalSolvedAllTime;

    // ── Error messages ──
    char loginErr[128];
    char regErr[128];
    char verifyErr[128];
    char verifyHint[128];
    char pendingToken[16];
    char syntaxErr[512];   // compile error from Judge

    // ── Pending user for verify ──
    AppUser* pendingUser;

    // ── Login screen widgets ──
    Button   btnTabLogin, btnTabReg, btnTabVerify;
    InputBox inpUser, inpPass;
    Button   btnLogin;
    InputBox inpRegUser, inpRegEmail, inpRegPass;
    Button   btnRegister;
    InputBox inpToken;
    Button   btnVerify;

    // ── Dashboard widgets ──
    Button btnDiff[5];
    Button btnStart;
    Button btnLogout;

    // ── Contest widgets ──
    Button   btnProb[3];
    InputBox inpCode;
    Button   btnSubmit;
    Button   btnEndContest;

    // ── Results widgets ──
    Button btnBackDash;

    // ── Draw helpers ──
    void rect(float x, float y, float w, float h, sf::Color fill,
              sf::Color out = C::TRANS, float outThick = 0);
    void line(float x1, float y1, float x2, float y2, sf::Color col, float thick = 1.f);
    sf::Text txt(const char* s, unsigned sz, sf::Color col, float x, float y);
    void ctxt(const char* s, unsigned sz, sf::Color col, float cx, float y);
    void badge(const char* s, float x, float y, float w, float h, sf::Color bg, sf::Color fg);

    // ── Logic ──
    void doLogin();
    void doRegister();
    void doVerify();
    void doStartContest();
    void doSubmit();
    void doEndContest();
    void updateTimer();

    // ── Draw screens ──
    void drawLogin();
    void drawDashboard();
    void drawContest();
    void drawResults();

    // ── Event screens ──
    void evLogin(sf::Event& e);
    void evDashboard(sf::Event& e);
    void evContest(sf::Event& e);
    void evResults(sf::Event& e);

    void initWidgets();

public:
    GUI();
    ~GUI();
    void run();
};

#endif
