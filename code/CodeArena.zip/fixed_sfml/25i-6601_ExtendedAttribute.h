#ifndef EXTENDEDATTRIBUTE_H
#define EXTENDEDATTRIBUTE_H

class ExtendedAttribute {
public:
    char* key;
    char* value;

    ExtendedAttribute();
    ExtendedAttribute(const char* k, const char* v);
    ExtendedAttribute& operator=(const ExtendedAttribute& other);
    ~ExtendedAttribute();

    void display();
};

#endif