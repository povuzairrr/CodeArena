#include "SharedInterfaces.h"
#include "25i-6601_Helper.h"
#include<iostream>
using namespace std;

EasyContest::EasyContest(AppUser* user, VFSAdapter& vfs): Contest(user, 3600, MyString("/contests/easy/"))
{

}

void EasyContest::buildProblemSet(ProblemBank& bank)
{
    DynamicArray<Problem*> easy = bank.getByDifficulty(1);
    for(int i = 0; i < easy.size(); i++)
    {
        problemSet.push(easy.get(i));
    }
}
