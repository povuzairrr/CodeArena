#include "SharedInterfaces.h"

Directory* VFSAdapter::traversePath(const char* path) {
    int i = 0;
    if (path[i] == '/') i++;
    Directory* current = root;
    char segment[256];
    int segIdx = 0;
    while (path[i] != '\0') {
        if (path[i] == '/') {
            segment[segIdx] = '\0';
            segIdx = 0;
            if (segment[0] == '\0') { i++; continue; }
            FSEntity* next = current->findChild(segment);
            if (next == nullptr || next->type != DIRECTORY_TYPE) return nullptr;
            current = (Directory*)next;
        } else {
            segment[segIdx++] = path[i];
        }
        i++;
    }
    // Process the final segment (no trailing slash case)
    if (segIdx > 0) {
        segment[segIdx] = '\0';
        FSEntity* next = current->findChild(segment);
        if (next == nullptr || next->type != DIRECTORY_TYPE) return nullptr;
        current = (Directory*)next;
    }
    return current;
}
void VFSAdapter::getLastSegment(const char* path, char* dest) {
    // Strip trailing slash first
    int len = strlen(path);
    char tmp[512];
    strncpy(tmp, path, 511); tmp[511] = '\0';
    while (len > 1 && tmp[len-1] == '/') tmp[--len] = '\0';

    int last = -1;
    for (int i = 0; tmp[i] != '\0'; i++)
        if (tmp[i] == '/') last = i;
    if (last == -1) strcpy(dest, tmp);
    else strcpy(dest, tmp + last + 1);
}
void VFSAdapter::getParentPath(const char* path, char* dest) {
    // Strip trailing slash first
    int len = strlen(path);
    char tmp[512];
    strncpy(tmp, path, 511); tmp[511] = '\0';
    while (len > 1 && tmp[len-1] == '/') tmp[--len] = '\0';

    int last = -1;
    for (int i = 0; tmp[i] != '\0'; i++)
        if (tmp[i] == '/') last = i;
    if (last <= 0) { dest[0] = '/'; dest[1] = '\0'; }
    else { strncpy(dest, tmp, last); dest[last] = '\0'; }
}
VFSAdapter::VFSAdapter() {
    root = new Directory("/", "2026-01-01", nullptr, nullptr);
}
VFSAdapter::~VFSAdapter() {
    delete root;
}
void VFSAdapter::createDir(const MyString& path) {
    // mkdir -p: ensure all intermediate dirs exist
    const char* p = path.c_str();
    int len = strlen(p);
    char tmp[512];
    strncpy(tmp, p, 511); tmp[511] = '\0';
    // strip trailing slash
    while (len > 1 && tmp[len-1] == '/') tmp[--len] = '\0';

    // Walk each segment and create if missing
    char cur[512]; cur[0] = '/'; cur[1] = '\0';
    int i = 0;
    if (tmp[i] == '/') i++;
    while (tmp[i]) {
        char seg[256]; int si = 0;
        while (tmp[i] && tmp[i] != '/') seg[si++] = tmp[i++];
        seg[si] = '\0';
        if (si == 0) { if (tmp[i]) i++; continue; }
        // ensure cur dir exists, then descend
        Directory* parent = traversePath(cur);
        if (parent && parent->findChild(seg) == nullptr) {
            Directory* nd = new Directory(seg, "2026-01-01", nullptr, parent);
            parent->addChild(nd);
        }
        // append seg to cur
        if (cur[1]) strcat(cur, "/");
        strcat(cur, seg);
        if (tmp[i] == '/') i++;
    }
}
void VFSAdapter::writeFile(const MyString& path, const MyString& data) {
    char parentPath[512], fileName[256];
    getParentPath(path.c_str(), parentPath);
    getLastSegment(path.c_str(), fileName);
    Directory* parent = traversePath(parentPath);
    if (parent == nullptr) return;
    FSEntity* existing = parent->findChild(fileName);
    if (existing != nullptr && existing->type == FILE_TYPE) {
        ((File*)existing)->setContent(data.c_str(), nullptr);
        return;
    }
    File* newFile = new File(fileName, "2026-01-01", nullptr, data.c_str());
    parent->addChild(newFile);
}
MyString VFSAdapter::readFile(const MyString& path) {
    char parentPath[512], fileName[256];
    getParentPath(path.c_str(), parentPath);
    getLastSegment(path.c_str(), fileName);
    Directory* parent = traversePath(parentPath);
    if (parent == nullptr) return MyString("");
    FSEntity* entity = parent->findChild(fileName);
    if (entity == nullptr || entity->type != FILE_TYPE) return MyString("");
    return MyString(((File*)entity)->content);
}
bool VFSAdapter::exists(const MyString& path) {
    char parentPath[512], lastName[256];
    getParentPath(path.c_str(), parentPath);
    getLastSegment(path.c_str(), lastName);
    if (lastName[0] == '\0') return false;
    Directory* parent = traversePath(parentPath);
    if (parent == nullptr) return false;
    return parent->findChild(lastName) != nullptr;
}
void VFSAdapter::deleteDir(const MyString& path) {
    char parentPath[512], dirName[256];
    getParentPath(path.c_str(), parentPath);
    getLastSegment(path.c_str(), dirName);
    Directory* parent = traversePath(parentPath);
    if (parent == nullptr) return;
    parent->removeChild(dirName);
}
