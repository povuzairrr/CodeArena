#include "SharedInterfaces.h"
#include "25i-6601_Helper.h"
#include<iostream>
using namespace std;

MediumContest::MediumContest(AppUser* user, VFSAdapter& vfs): Contest(user, 3600, MyString("/contests/medium/"))
{

}

void MediumContest::buildProblemSet(ProblemBank& bank)
{
    DynamicArray<Problem*> medium = bank.getByDifficulty(3);

    for(int i=0; i< medium.size(); i++)
    {
        problemSet.push(medium.get(i));
    }
}