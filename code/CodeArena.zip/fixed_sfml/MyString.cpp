#include<iostream>
#include "SharedInterfaces.h"
#include "25i-6601_Helper.h"


MyString::MyString()
{
    // Initialize to empty string instead of nullptr to prevent null-deref in SFML
    data = new char[1];
    data[0] = '\0';
    len = 0;
}

MyString::MyString(const char* str)
{
    if (str == nullptr) {
        data = new char[1];
        data[0] = '\0';
        len = 0;
        return;
    }
    len = strlen(str);
    data = new char[len + 1];
    strcpy(data, str);
}

MyString::MyString(const MyString& other)
{
    this->len = other.len;
    if (other.data == nullptr)
    {
        this->data = new char[1];
        this->data[0] = '\0';
        this->len = 0;
    }
    else
    {
        this->data = new char[other.len + 1];
        strcpy(this->data, other.data);
    }
}

MyString& MyString::operator=(const MyString& other)
{
    if(this == &other)
    return *this;

    delete[] this->data;

    this->len = other.len;

    if (other.data == nullptr)
    {
        this->data = new char[1];
        this->data[0] = '\0';
        this->len = 0;
    }
    else
    {
        this->data = new char[strlen(other.data) + 1];
        strcpy(this->data, other.data);
    }

    return *this;
}

bool MyString::operator==(const MyString& other) const
{
    const char* a = (this->data != nullptr) ? this->data : "";
    const char* b = (other.data != nullptr) ? other.data : "";
    return strcmp(a, b) == 0;
}

MyString::~MyString()
{
    delete[] data;
}

MyString MyString::operator+(const MyString& other) const
{
    const char* a = (this->data != nullptr) ? this->data : "";
    const char* b = (other.data != nullptr) ? other.data : "";
    int newLen = strlen(a) + strlen(b);
    char* temp = new char[newLen + 1];
    strcpy(temp, a);
    strcat(temp, b);
    MyString result(temp);
    delete[] temp;
    return result;
}

MyString& MyString::operator=(const char* str)
{
    if (str == nullptr)
    {
        delete[] data;
        data = new char[1];
        data[0] = '\0';
        len = 0;
        return *this;
    }

    delete[] data;
    len = strlen(str);
    data = new char[len + 1];
    strcpy(data, str);

    return *this;
}

bool MyString::operator!=(const MyString& other) const
{
    const char* a = (this->data != nullptr) ? this->data : "";
    const char* b = (other.data != nullptr) ? other.data : "";
    return strcmp(a, b) != 0;
}

const char* MyString::c_str() const
{
    // Never return nullptr — sf::Text::setString crashes on null pointer
    return (data != nullptr) ? data : "";
}

int MyString::length() const
{
    return len;
}

bool MyString::isEmpty() const
{
    if(len == 0 || data == nullptr)
    return true;

    else
    return false;
}
