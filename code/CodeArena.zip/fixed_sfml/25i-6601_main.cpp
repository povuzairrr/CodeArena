#include <iostream>
#include "25i-6601_Helper.h"
#include "25i-6601_Volume.h"
#include "25i-6601_StorageMedium.h"
#include "25i-6601_Partition.h"
#include "25i-6601_User.h"
#include "25i-6601_Directory.h"
#include "25i-6601_File.h"
#include "25i-6601_SymbolicLink.h"
#include "25i-6601_MountPoint.h"
using namespace std;

int main()
{
    cout << "1. Run predefined demo" << endl;
    cout << "2. Interactive mode" << endl;
    cout << "Choice: ";
    int choice;
    cin >> choice;
    cin.ignore();

    Volume vfs("VFS");

    StorageMedium* hdd = new StorageMedium("HDD1", 1000.0f, HDD);
    StorageMedium* ssd = new StorageMedium("SSD1", 500.0f, SSD);
    hdd->mount();
    ssd->mount();
    vfs.addMedium(hdd);
    vfs.addMedium(ssd);

    Partition* p1 = new Partition("P1", 600.0f, EXT4, hdd);
    Partition* p2 = new Partition("P2", 300.0f, NTFS, hdd);
    Partition* p3 = new Partition("P3", 400.0f, EXT4, ssd);

    User* admin = new User("root",  0, "/root",   ADMIN);
    User* userA = new User("userA", 1, "/home/a", STANDARD);
    User* userB = new User("userB", 2, "/home/b", STANDARD);
    vfs.addUser(admin);
    vfs.addUser(userA);
    vfs.addUser(userB);

    // level 1
    Directory* home = new Directory("home", "2026-01-01", admin, vfs.root);
    Directory* etc  = new Directory("etc",  "2026-01-01", admin, vfs.root);
    vfs.root->addChild(home);
    vfs.root->addChild(etc);

    // level 2
    Directory* dirA = new Directory("a", "2026-01-01", userA, home);
    Directory* dirB = new Directory("b", "2026-01-01", userB, home);
    home->addChild(dirA);
    home->addChild(dirB);

    // level 3 files
    File* f1 = new File("file1.txt", "2026-01-01", userA, "aaa");
    File* f2 = new File("file2.txt", "2026-01-01", userA, "bbb");
    File* f3 = new File("file3.txt", "2026-01-01", userB, "ccc");
    File* f4 = new File("hosts",     "2026-01-01", admin, "xyz");

    f1->permission.setOwner(true, true, false);
    f1->permission.setGroup(true, false, false);
    f1->permission.setOthers(false, false, false);

    dirA->addChild(f1);
    dirA->addChild(f2);
    dirB->addChild(f3);
    etc->addChild(f4);

    f1->addAttribute("type", "text");

    // valid symlink
    SymbolicLink* lnk = new SymbolicLink("link1", "2026-01-01", userA, f1);
    dirA->addChild(lnk);

    // dangling symlink
    SymbolicLink* broken = new SymbolicLink("link2", "2026-01-01", userA, nullptr);
    dirA->addChild(broken);

    // mount point
    MountPoint* mp = new MountPoint("mnt", "2026-01-01", admin, vfs.root);
    vfs.root->addChild(mp);
    mp->mountPartition(p3);
    vfs.addMountPoint(mp);

    if(choice == 1)
    {
        cout << "\n--- Shallow list of /home ---" << endl;
        home->listShallow();

        cout << "\n--- Edit file1.txt ---" << endl;
        f1->setContent("updated aaa", userA);
        f1->displayHistory();

        cout << "\n--- Size of /home ---" << endl;
        cout << home->computeSize() << " characters" << endl;

        cout << "\n--- Dangling links ---" << endl;
        vfs.detectDanglingLinks(vfs.root);

        // permission failure
        cout << "\n--- Permission violation ---" << endl;
        if(!f1->permission.canOthersWrite())
            cout << "ACCESS DENIED: userB cannot write to file1.txt" << endl;

        // capacity failure
        cout << "\n--- Capacity violation ---" << endl;
        if(!p3->canFit(999999.0f))
            cout << "REJECTED: not enough space on P3" << endl;

        cout << "\n--- Volume ---" << endl;
        vfs.display();
    }
    else if(choice == 2)
    {
        int op = -1;
        while(op != 0)
        {
            cout << "\n1. List /home (shallow)" << endl;
            cout << "2. Edit file1.txt" << endl;
            cout << "3. Show size of /home" << endl;
            cout << "4. Detect dangling links" << endl;
            cout << "5. Add file to dirA" << endl;
            cout << "6. Add user" << endl;
            cout << "7. Display volume" << endl;
            cout << "0. Exit" << endl;
            cout << "Choice: ";
            cin >> op;
            cin.ignore();

            switch(op)
            {
                case 1:
                    home->listShallow();
                    break;

                case 2:
                {
                    char newContent[200];
                    cout << "Enter new content: ";
                    cin.getline(newContent, 200);
                    f1->setContent(newContent, userA);
                    cout << "Done. History:" << endl;
                    f1->displayHistory();
                    break;
                }

                case 3:
                    cout << "Size: " << home->computeSize() << " characters" << endl;
                    break;

                case 4:
                    vfs.detectDanglingLinks(vfs.root);
                    break;

                case 5:
                {
                    char fname[100];
                    char fcontent[200];
                    cout << "File name: ";
                    cin.getline(fname, 100);
                    cout << "Content: ";
                    cin.getline(fcontent, 200);
                    File* newFile = new File(fname, "2026-01-01", userA, fcontent);
                    dirA->addChild(newFile);
                    cout << "File added." << endl;
                    break;
                }

                case 6:
                {
                    char uname[100];
                    int uid;
                    cout << "Username: ";
                    cin.getline(uname, 100);
                    cout << "User ID: ";
                    cin >> uid;
                    cin.ignore();
                    User* newUser = new User(uname, uid, "/home/x", STANDARD);
                    vfs.addUser(newUser);
                    cout << "User added." << endl;
                    break;
                }

                case 7:
                    vfs.display();
                    break;

                case 0:
                    cout << "Exiting." << endl;
                    break;

                default:
                    cout << "Invalid option." << endl;
            }
        }
    }

    return 0;
}