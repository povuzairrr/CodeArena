#include "25i-6601_Partition.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
Partition::Partition()
{
    label = new char[1];
    strcpy(label, "");

    allocatedCapacity = 0;
    usedSpace = 0;

    formatType = FAT32;

    medium = nullptr;
}

// Parameterized constructor
Partition::Partition(const char* l, float capacity, int format, StorageMedium* m)
{
    label = new char[strlen(l) + 1];
    strcpy(label, l);

    medium = m;     // assign medium first before using it

    if(capacity > medium->getAvailableSpace())
    {
        cout<<"Partition cannot exceed medium's available capacity\nMaking capacity = 0\n";
        allocatedCapacity = 0;
    }
    else
    {
        allocatedCapacity = capacity;
    }

    usedSpace = 0;

    formatType = format;

    medium->usedCapacity += allocatedCapacity;  // update medium's used capacity
}

// Destructor
// Do NOT delete medium, we dont own it
Partition::~Partition()
{
    delete[] label;
}

float Partition::getAvailableSpace()
{
    return (allocatedCapacity - usedSpace);
}


bool Partition::canFit(float sizeMB)
{
    return getAvailableSpace() >= sizeMB;
}


void Partition::display()
{
    cout<<"Partition Label: "<<label<<endl;
    cout<<"Allocated Space: "<<allocatedCapacity<<endl;
    cout<<"Used Space: "<<usedSpace<<endl;
    cout<<"Availiable Space: "<<getAvailableSpace()<<endl;

    cout<<"Format: ";
    if(formatType == FAT32)
    cout<<"FAT32\n";

    else if(formatType == NTFS)
    cout<<"NTFS\n";

    else
    cout<<"EXT4\n";

    cout<<"Medium Name: "<<medium->name<<endl;
}