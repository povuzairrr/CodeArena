#include "25i-6601_VersionRecord.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
VersionRecord::VersionRecord()
{
    content = new char[1];
    strcpy(content, "");

    timestamp = new char[1];
    strcpy(timestamp, "");

    editedBy = nullptr;
}

// Parameterized constructor
VersionRecord::VersionRecord(const char* oldContent, const char* time, User* user)
{
    content = new char[strlen(oldContent) + 1];
    strcpy(this->content, oldContent );

    timestamp = new char[strlen(time) + 1];
    strcpy(this->timestamp, time);

    editedBy = user;
}

// Destructor
//We Do NOT delete editedBy, we dont own the user object
VersionRecord::~VersionRecord()
{
    delete[] content;
    delete[] timestamp;
}

// Prints old content, timestamp, and username of who edited it
void VersionRecord::display()
{
    cout<<" Content: "<<content<<endl;
    cout<<"Time: "<<timestamp<<endl;


    if(editedBy != nullptr)
        cout << "User: " << editedBy->username << endl;
    else
        cout << "User: unknown" << endl;       // this is just edge case to handle possiblity of user not existing
}