#include "SharedInterfaces.h"
#include <cstdio>
#include <sys/stat.h>
#include <sys/types.h>

// djb2 hash — turns a password into a number stored as MyString
static MyString hashPassword(const char* pw) {
    unsigned long h = 5381;
    for (int i = 0; pw[i] != '\0'; i++)
        h = ((h << 5) + h) + (unsigned char)pw[i];
    char buf[32];
    int idx = 31;
    buf[idx] = '\0';
    if (h == 0) {
        buf[--idx] = '0';
    } else {
        while (h > 0) {
            buf[--idx] = '0' + (h % 10);
            h /= 10;
        }
    }
    return MyString(buf + idx);
}

static MyString buildHomePath(const MyString& username) {
    return MyString("/users/") + username + MyString("/");
}

static MyString getLine(const MyString& text, int lineIndex) {
    const char* s = text.c_str();
    int curLine = 0, i = 0;
    while (s[i] != '\0') {
        if (curLine == lineIndex) {
            int start = i;
            while (s[i] != '\0' && s[i] != '\n') i++;
            int len = i - start;
            char* buf = new char[len + 1];
            for (int j = 0; j < len; j++) buf[j] = s[start + j];
            buf[len] = '\0';
            MyString result(buf);
            delete[] buf;
            return result;
        }
        if (s[i] == '\n') curLine++;
        i++;
    }
    return MyString("");
}

// ── Disk helpers ─────────────────────────────────────────────
// Real path on disk: ./codearena_users/<username>/profile.txt
// This persists across runs. VFS is only used for contest/problem data.

static void diskPath(char* dest, const char* username) {
    sprintf(dest, "codearena_users/%s/profile.txt", username);
}

static void diskDir(char* dest, const char* username) {
    sprintf(dest, "codearena_users/%s", username);
}

static bool diskExists(const char* username) {
    char path[256];
    diskPath(path, username);
    FILE* f = fopen(path, "r");
    if (f) { fclose(f); return true; }
    return false;
}

static void ensureBaseDir() {
    mkdir("codearena_users", 0755);
}

// ─── AppUser ──────────────────────────────────────────────────

AppUser::AppUser() : isVerified(false) {}

AppUser::AppUser(const char* username, const char* email, const char* password)
    : username(username), email(email), isVerified(false) {
    passwordHash = hashPassword(password);
    vfsHomePath  = buildHomePath(this->username);
}

bool AppUser::registerUser(VFSAdapter& vfs) {
    // Check on DISK (persistent), not VFS (in-memory)
    MyString unameTemp = username;
    const char* uname = unameTemp.c_str();
    if (diskExists(uname)) return false;

    // Create disk directory for this user
    ensureBaseDir();
    char dir[256];
    diskDir(dir, uname);
    mkdir(dir, 0755);

    // Save to disk
    char path[256];
    diskPath(path, uname);
    serialize(path);

    // Also create VFS home dir (for contest data during this session)
    vfs.createDir(vfsHomePath);
    return true;
}

bool AppUser::verify(const char* token) {
    if (username == MyString(token)) {
        isVerified = true;
        return true;
    }
    return false;
}

bool AppUser::checkPassword(const char* password) const {
    return passwordHash == hashPassword(password);
}

void AppUser::deleteAccount(VFSAdapter& vfs) {
    vfs.deleteDir(vfsHomePath);
}

MyString AppUser::getUsername()    const { return username; }
MyString AppUser::getEmail()       const { return email; }
MyString AppUser::getVfsHomePath() const { return vfsHomePath; }
bool     AppUser::getIsVerified()  const { return isVerified; }

static VFSAdapter* gVFS = nullptr;
void AppUser::setGlobalVFS(VFSAdapter* vfs) { gVFS = vfs; }

// serialize — writes to REAL DISK file at given path
void AppUser::serialize(const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) return;
    fprintf(f, "%s\n", username.c_str());
    fprintf(f, "%s\n", email.c_str());
    fprintf(f, "%s\n", passwordHash.c_str());
    fprintf(f, "%s\n", isVerified ? "1" : "0");
    fprintf(f, "%s\n", vfsHomePath.c_str());
    fclose(f);
}

// deserialize — reads from REAL DISK file at given path
void AppUser::deserialize(const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) return;
    char buf[512];
    auto readln = [&](char* dest) {
        dest[0] = '\0';
        if (!fgets(buf, 511, f)) return;
        int i = 0;
        while (buf[i] && buf[i] != '\n' && buf[i] != '\r') { dest[i] = buf[i]; i++; }
        dest[i] = '\0';
    };
    char u[256], e[256], ph[256], iv[4], vp[256];
    readln(u);  readln(e);  readln(ph);  readln(iv);  readln(vp);
    fclose(f);
    username     = MyString(u);
    email        = MyString(e);
    passwordHash = MyString(ph);
    isVerified   = (iv[0] == '1');
    vfsHomePath  = MyString(vp);
}
