#include "25i-6601_SymbolicLink.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
SymbolicLink::SymbolicLink() : FSEntity()
{
    target = nullptr;
}

// Parameterized constructor
SymbolicLink::SymbolicLink(const char* n, const char* created, User* o, FSEntity* t)
: FSEntity(n, created, o, SYMLINK_TYPE)
{
    target = t;
}

// Destructor
// We Do NOT delete target, we dont own it
SymbolicLink::~SymbolicLink()
{
    
}

// Returns true if target is nullptr, false otherwise
// Used by Volume to detect all dangling symlinks across the hierarchy
bool SymbolicLink::isDangling()
{
    if(target == nullptr)
    return true;

    else
    return false;
}

// Updates the target pointer to a new FSEntity
void SymbolicLink::setTarget(FSEntity* t)
{
    target = t;
}

// Returns the current target pointer
FSEntity* SymbolicLink::getTarget()
{
    return target;
}


void SymbolicLink::display()
{
    displayInfo();
    
    if(target==nullptr)
    {
        cout<<"Target is nullptr\n";
        return;
    }

    cout<<"Name: "<<target->name<<endl;
}

// Symbolic links are just shortcuts so size is always 0
int SymbolicLink::getSize()
{
    return 0;
}