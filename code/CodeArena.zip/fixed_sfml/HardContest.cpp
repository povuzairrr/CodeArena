#include "SharedInterfaces.h"
#include "25i-6601_Helper.h"
#include<iostream>
using namespace std;

HardContest::HardContest(AppUser* user, VFSAdapter& vfs): Contest(user, 3600, MyString("/contests/hard/"))
{

}

void HardContest::buildProblemSet(ProblemBank& bank)
{
    DynamicArray<Problem*> hard4 = bank.getByDifficulty(4);
    for(int i = 0; i < hard4.size(); i++)
    {
        problemSet.push(hard4.get(i));
    }

    DynamicArray<Problem*> hard5 = bank.getByDifficulty(5);
    for(int i = 0; i < hard5.size(); i++)
    {
        problemSet.push(hard5.get(i));
    }
}
