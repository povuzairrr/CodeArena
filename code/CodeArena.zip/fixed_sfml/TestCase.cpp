#include "SharedInterfaces.h"

// ─── TestCase ────────────────────────────────────────────────

TestCase::TestCase() {}

TestCase::TestCase(const char* in, const char* expected)
    : input(in), expectedOutput(expected) {}

MyString TestCase::getInput() const {
    return input;
}

MyString TestCase::getExpected() const {
    return expectedOutput;
}
