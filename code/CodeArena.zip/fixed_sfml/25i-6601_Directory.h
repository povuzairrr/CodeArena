#ifndef DIRECTORY_H
#define DIRECTORY_H

#include "25i-6601_FSEntity.h"

class Directory : public FSEntity {
public:
    FSEntity** children;        
    int childCount;
    Directory* parent;          

    Directory();
    Directory(const char* n, const char* created, User* o, Directory* p);
    ~Directory();

    void addChild(FSEntity* entity);        
    void removeChild(const char* n);        
    FSEntity* findChild(const char* n);     

    void listShallow();                     
    void listDeep(int depth);              

    FSEntity* search(const char* pattern); 
    int computeSize();                     

    void display();                        
    int getSize();                         
};

#endif