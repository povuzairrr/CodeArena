#include "25i-6601_StorageMedium.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
StorageMedium::StorageMedium()
{
    name = new char[1];
    strcpy(name, "");
    
    totalCapacity = 0;
    usedCapacity = 0;

    mediaType = HDD;

    isMounted = false;
}

// Parameterized constructor
StorageMedium::StorageMedium(const char* n, float capacity, int type)
{
    name = new char[strlen(n) + 1];
    strcpy(name, n);

    totalCapacity = capacity;

    mediaType = type;

    usedCapacity = 0;

    isMounted = false;
}

// Destructor
StorageMedium::~StorageMedium()
{
    delete[] name;
}


float StorageMedium::getAvailableSpace()
{
    return (totalCapacity - usedCapacity);
}


void StorageMedium::mount()
{
    isMounted = true;
    cout<<"Storage medium mounted ...\n";
}


void StorageMedium::unmount()
{
    isMounted = false;
    cout<<"Storage medium Unmounted ...\n";
}


void StorageMedium::display()
{
    cout<<"Disk Name: "<<name<<endl;
    cout<<"Total Capacity: "<<totalCapacity<<"mb"<<endl;
    cout<<"Used Capacity: "<<usedCapacity<<"mbs"<<endl;
    cout<<"Available Space: "<<totalCapacity - usedCapacity<<"mb"<<endl;
    
    if(mediaType == HDD)
    cout << "Media Type: HDD" << endl;
    else if(mediaType == SSD)
    cout << "Media Type: SSD" << endl;
    else
    cout << "Media Type: Optical" << endl;

    cout << "Mount State: " << (isMounted ? "Mounted" : "Unmounted") << endl;
}