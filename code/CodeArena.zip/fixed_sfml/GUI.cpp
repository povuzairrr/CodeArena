#include "GUI.h"
#include <string>

// ════════════════════════════════════════════════════════════
//  InputBox
// ════════════════════════════════════════════════════════════
InputBox::InputBox() : bufLen(0), focused(false), isPassword(false), cursorVisible(true), cursorPos(0) { buf[0] = '\0'; }

void InputBox::init(const sf::Font& f, float x, float y, float w, float h, const char* ph, bool pw) {
    isPassword = pw;
    box.setPosition(x, y);
    box.setSize({w, h});
    box.setFillColor(C::SURF2);
    box.setOutlineThickness(1.f);
    box.setOutlineColor(C::BORDER);
    displayText.setFont(f);
    displayText.setCharacterSize(14);
    displayText.setFillColor(C::TEXT);
    displayText.setPosition(x + 12, y + (h - 16) / 2.f);
    placeholderText.setFont(f);
    placeholderText.setString(ph);
    placeholderText.setCharacterSize(14);
    placeholderText.setFillColor(sf::Color(70, 70, 70));
    placeholderText.setPosition(x + 12, y + (h - 16) / 2.f);
}
void InputBox::handleEvent(sf::Event& e) {
    if (!focused) return;

    // ── Arrow key navigation (KeyPressed event) ──
    if (e.type == sf::Event::KeyPressed) {
        bool ml = (box.getSize().y > 80.f);
        if (e.key.code == sf::Keyboard::Left) {
            if (cursorPos > 0) cursorPos--;
        } else if (e.key.code == sf::Keyboard::Right) {
            if (cursorPos < bufLen) cursorPos++;
        } else if (ml && e.key.code == sf::Keyboard::Up) {
            // Find start of current line and previous line
            int lineStart = cursorPos;
            while (lineStart > 0 && buf[lineStart-1] != '\n') lineStart--;
            int col = cursorPos - lineStart;
            if (lineStart > 0) {
                // go to end of prev line
                int prevEnd = lineStart - 1;  // the \n char
                int prevStart = prevEnd;
                while (prevStart > 0 && buf[prevStart-1] != '\n') prevStart--;
                int prevLen = prevEnd - prevStart;
                cursorPos = prevStart + (col < prevLen ? col : prevLen);
            }
        } else if (ml && e.key.code == sf::Keyboard::Down) {
            // Find start of next line
            int lineStart = cursorPos;
            while (lineStart > 0 && buf[lineStart-1] != '\n') lineStart--;
            int col = cursorPos - lineStart;
            // find end of current line
            int lineEnd = cursorPos;
            while (lineEnd < bufLen && buf[lineEnd] != '\n') lineEnd++;
            if (lineEnd < bufLen) {
                int nextStart = lineEnd + 1;
                int nextEnd = nextStart;
                while (nextEnd < bufLen && buf[nextEnd] != '\n') nextEnd++;
                int nextLen = nextEnd - nextStart;
                cursorPos = nextStart + (col < nextLen ? col : nextLen);
            }
        } else if (e.key.code == sf::Keyboard::Home) {
            // go to start of current line
            while (cursorPos > 0 && buf[cursorPos-1] != '\n') cursorPos--;
        } else if (e.key.code == sf::Keyboard::End) {
            while (cursorPos < bufLen && buf[cursorPos] != '\n') cursorPos++;
        } else if (e.key.code == sf::Keyboard::Delete) {
            if (cursorPos < bufLen) {
                for (int i = cursorPos; i < bufLen; i++) buf[i] = buf[i+1];
                bufLen--;
            }
        } else if (e.key.code == sf::Keyboard::V && e.key.control) {
            // Ctrl+V — paste from system clipboard
            sf::String clip = sf::Clipboard::getString();
            std::string s = clip.toAnsiString();
            for (int ci = 0; ci < (int)s.size() && bufLen < 8190; ci++) {
                char ch = s[ci];
                // For password/single-line boxes skip newlines
                bool isMultiline = (box.getSize().y > 80.f);
                if ((ch == '\n' || ch == '\r') && (!isMultiline || isPassword)) continue;
                if (ch == '\r') continue;  // skip CR regardless
                if ((unsigned char)ch < 32 && ch != '\n') continue;  // skip control chars except newline
                for (int i = bufLen; i > cursorPos; i--) buf[i] = buf[i-1];
                buf[cursorPos++] = ch;
                buf[++bufLen]    = '\0';
            }
        } else if (e.key.code == sf::Keyboard::A && e.key.control) {
            // Ctrl+A — select all (for code box: move cursor to end)
            cursorPos = bufLen;
        }
        return;
    }

    if (e.type == sf::Event::TextEntered) {
        uint32_t u = e.text.unicode;
        if (u == 8) {  // Backspace — delete char before cursor
            if (cursorPos > 0) {
                for (int i = cursorPos-1; i < bufLen-1; i++) buf[i] = buf[i+1];
                buf[--bufLen] = '\0';
                cursorPos--;
            }
        } else if ((u == 13 || u == 10) && !isPassword
                   && box.getSize().y > 80.f && bufLen < 8189) {
            // Insert newline at cursorPos
            for (int i = bufLen; i > cursorPos; i--) buf[i] = buf[i-1];
            buf[cursorPos++] = '\n';
            buf[++bufLen]    = '\0';
            buf[bufLen]      = '\0';
        } else if (u >= 32 && u < 127 && bufLen < 8190) {
            // Insert char at cursorPos
            for (int i = bufLen; i > cursorPos; i--) buf[i] = buf[i-1];
            buf[cursorPos++] = (char)u;
            buf[++bufLen]    = '\0';
            buf[bufLen]      = '\0';
        }
    }
}
void InputBox::draw(sf::RenderWindow& w) {
    box.setOutlineColor(focused ? C::RED : C::BORDER);
    w.draw(box);
    sf::Vector2f bpos = box.getPosition();
    sf::Vector2f bsz  = box.getSize();

    bool multiline = (bsz.y > 80.f);
    float tx = bpos.x + 12;
    float ty = multiline ? bpos.y + 10 : bpos.y + (bsz.y - 16) / 2.f;

    displayText.setPosition(tx, ty);
    placeholderText.setPosition(tx, ty);

    if (bufLen == 0) {
        w.draw(placeholderText);
    } else {
        if (isPassword) {
            char stars[256];
            for (int i = 0; i < bufLen; i++) stars[i] = '*';
            stars[bufLen] = '\0';
            displayText.setString(stars);
        } else {
            displayText.setString(buf);
        }
        w.draw(displayText);
    }

    // ── Blinking cursor ──
    if (focused) {
        if (cursorClock.getElapsedTime().asSeconds() >= 0.5f) {
            cursorVisible = !cursorVisible;
            cursorClock.restart();
        }
        if (cursorVisible) {
            // LINE_H: measured from sf::Text line spacing for charSize=14 monospace
            // sf::Text renders each line at charSize * font.getLineSpacing(charSize)
            // For DejaVuSansMono at 14px this is ~21px. We measure it directly:
            const float LINE_H = displayText.getFont()
                ? displayText.getFont()->getLineSpacing(displayText.getCharacterSize())
                : 21.f;

            float curX = tx, curY = ty;
            // Use cursorPos (not bufLen) so cursor tracks insertion point
            int drawPos = cursorPos;
            int lineStart = 0;

            if (drawPos > 0 || bufLen > 0) {
                int lineCount = 0;
                for (int i = 0; i < drawPos; i++) {
                    if (buf[i] == '\n') {
                        lineStart = i + 1;
                        lineCount++;
                    }
                }
                if (multiline) curY = ty + lineCount * LINE_H;

                // X: chars from lineStart to cursorPos on the current line
                char curLine[512];
                int ll = 0;
                for (int i = lineStart; i < drawPos && ll < 510; i++)
                    curLine[ll++] = buf[i];
                curLine[ll] = '\0';

                if (ll > 0) {
                    sf::Text measure = displayText;
                    measure.setPosition(0, 0);
                    measure.setString(curLine);
                    sf::Vector2f endPos = measure.findCharacterPos(ll);
                    curX = tx + endPos.x;
                } else {
                    curX = tx;
                }
                if (!multiline) curY = ty;
            }

            // Clamp inside box
            if (curX > bpos.x + bsz.x - 4) curX = bpos.x + bsz.x - 4;
            if (curY < bpos.y + 2) curY = bpos.y + 2;
            if (curY > bpos.y + bsz.y - LINE_H) curY = bpos.y + bsz.y - LINE_H;

            sf::RectangleShape cur(sf::Vector2f(2.f, LINE_H - 2));
            cur.setFillColor(C::RED);
            cur.setPosition(curX, curY);
            w.draw(cur);
        }
    }
}
const char* InputBox::val() const { return buf; }
void InputBox::clear() { bufLen = 0; cursorPos = 0; buf[0] = '\0'; }
bool InputBox::empty() const { return bufLen == 0; }

// ════════════════════════════════════════════════════════════
//  Button
// ════════════════════════════════════════════════════════════
Button::Button() : isPrimary(false) {}

void Button::init(const sf::Font& f, float x, float y, float w, float h, const char* txt, bool primary) {
    isPrimary = primary;
    box.setPosition(x, y);
    box.setSize({w, h});
    box.setFillColor(primary ? C::RED : C::SURF2);
    box.setOutlineThickness(1.f);
    box.setOutlineColor(primary ? C::TRANS : C::BORDER);
    label.setFont(f);
    label.setString(txt);
    label.setCharacterSize(14);
    label.setFillColor(primary ? C::TEXT : C::MUTED);
    sf::FloatRect lb = label.getLocalBounds();
    label.setPosition(x + (w - lb.width) / 2.f - lb.left,
                      y + (h - lb.height) / 2.f - lb.top);
}
bool Button::contains(sf::Vector2f p) const { return box.getGlobalBounds().contains(p); }
void Button::draw(sf::RenderWindow& w, bool active) {
    sf::Vector2i mp = sf::Mouse::getPosition(w);
    bool hov = box.getGlobalBounds().contains((sf::Vector2f)mp);
    if (isPrimary) {
        box.setFillColor(hov ? C::RED_DIM : C::RED);
    } else {
        if (active || hov) {
            box.setOutlineColor(C::RED);
            label.setFillColor(C::RED);
            box.setFillColor(C::RED_GLO);
        } else {
            box.setOutlineColor(C::BORDER);
            label.setFillColor(C::MUTED);
            box.setFillColor(C::SURF2);
        }
    }
    w.draw(box);
    w.draw(label);
}

// ════════════════════════════════════════════════════════════
//  GUI helpers
// ════════════════════════════════════════════════════════════
void GUI::rect(float x, float y, float w, float h, sf::Color fill, sf::Color out, float outThick) {
    sf::RectangleShape r({w, h});
    r.setPosition(x, y);
    r.setFillColor(fill);
    if (outThick > 0) { r.setOutlineThickness(outThick); r.setOutlineColor(out); }
    win.draw(r);
}
void GUI::line(float x1, float y1, float x2, float y2, sf::Color col, float thick) {
    float dx = x2 - x1, dy = y2 - y1;
    float len = sqrtf(dx*dx + dy*dy);
    sf::RectangleShape r({len, thick});
    r.setPosition(x1, y1);
    r.setRotation(atan2f(dy, dx) * 180.f / 3.14159f);
    r.setFillColor(col);
    win.draw(r);
}
sf::Text GUI::txt(const char* s, unsigned sz, sf::Color col, float x, float y) {
    sf::Text t;
    t.setFont(font);
    t.setString(s);
    t.setCharacterSize(sz);
    t.setFillColor(col);
    t.setPosition(x, y);
    return t;
}
void GUI::ctxt(const char* s, unsigned sz, sf::Color col, float cx, float y) {
    sf::Text t = txt(s, sz, col, 0, y);
    sf::FloatRect lb = t.getLocalBounds();
    t.setPosition(cx - lb.width / 2.f - lb.left, y);
    win.draw(t);
}
void GUI::badge(const char* s, float x, float y, float w, float h, sf::Color bg, sf::Color fg) {
    rect(x, y, w, h, bg, C::TRANS);
    sf::Text t = txt(s, 10, fg, 0, 0);
    sf::FloatRect lb = t.getLocalBounds();
    t.setPosition(x + (w - lb.width) / 2.f - lb.left, y + (h - lb.height) / 2.f - lb.top);
    win.draw(t);
}

// ════════════════════════════════════════════════════════════
//  Init widgets
// ════════════════════════════════════════════════════════════
void GUI::initWidgets() {
    // Card: x=325, w=450, starts y=192. Tabs at y=200 (h=36). Separator at y=236.
    // Content area starts y=244. Pattern: label → 12px gap → input(h=40) → 14px → next label
    float cx = 325.f, cw = 450.f;

    // Login tabs
    btnTabLogin .init(font, cx,       200, cw/3, 36, "Login");
    btnTabReg   .init(font, cx+cw/3,  200, cw/3, 36, "Register");
    btnTabVerify.init(font, cx+2*cw/3,200, cw/3, 36, "Verify");

    // Login panel: label@244 → input@256(h=40) → label@310 → input@322(h=40) → btn@378(h=42)
    inpUser.init(font, cx+20, 256, cw-40, 40, "enter username");
    inpPass.init(font, cx+20, 322, cw-40, 40, "password", true);
    btnLogin.init(font, cx+20, 380, cw-40, 42, "Login", true);

    // Register panel (3 fields): label@244→inp@256(h=36)→label@304→inp@316(h=36)→label@364→inp@376(h=36)→btn@428(h=40)
    inpRegUser .init(font, cx+20, 256, cw-40, 36, "choose username");
    inpRegEmail.init(font, cx+20, 314, cw-40, 36, "email address");
    inpRegPass .init(font, cx+20, 372, cw-40, 36, "password", true);
    btnRegister.init(font, cx+20, 420, cw-40, 40, "Create Account", true);

    // Verify panel: text@248,@266 → label@280 → input@292(h=40) → btn@348(h=42)
    inpToken .init(font, cx+20, 282, cw-40, 40, "enter token or username");
    btnVerify.init(font, cx+20, 336, cw-40, 42, "Verify & Continue", true);

    // Dashboard
    const char* diffs[] = {"Level 1","Level 2","Level 3","Level 4","Level 5"};
    for (int i = 0; i < 5; i++)
        btnDiff[i].init(font, 60 + i*202.f, 296, 184, 42, diffs[i]);
    btnStart .init(font, 60,  358, 220, 48, "Start Contest ->", true);
    btnLogout.init(font, 970, 14,  110, 36, "Logout");

    // Contest
    {
    const char* pLabels[] = {"P1","P2","P3"};
    for (int i = 0; i < 3; i++)
        btnProb[i].init(font, i*140.f, 62, 140, 40, pLabels[i]);
    }
    inpCode.init(font, 432, 114, 656, 482, "#include <iostream>\nusing namespace std;\nint main() {\n    // your solution\n    return 0;\n}");
    btnSubmit    .init(font, 930, 612, 158, 42, "Submit ->", true);
    btnEndContest.init(font, 870, 16,  210, 36, "End Contest");

    // Results
    btnBackDash.init(font, 380, 626, 340, 46, "<- Back to Dashboard");
}

// ════════════════════════════════════════════════════════════
//  Constructor / Destructor
// ════════════════════════════════════════════════════════════
GUI::GUI()
    : win(sf::VideoMode(1100, 700), "CodeArena",
          sf::Style::Titlebar | sf::Style::Close),
      scr(SCR_LOGIN), tab(TAB_LOGIN),
      user(nullptr), pendingUser(nullptr),
      selectedDiff(1), contestDiff(1), contestOffset(0),
      timerSecs(3600), timerElapsed(0),
      currentProb(0), verdictSet(false), verdictOk(false),
      solvedCount(0), finalScore(0),
      totalContests(0), bestScore(0), totalSolvedAllTime(0)
{
    win.setFramerateLimit(60);

    // Try loading fonts
    bool loaded = font.loadFromFile("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf");
    if (!loaded) loaded = font.loadFromFile("/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf");
    if (!loaded) font.loadFromFile("C:/Windows/Fonts/consola.ttf");

    loginErr[0] = regErr[0] = verifyErr[0] = verifyHint[0] = pendingToken[0] = syntaxErr[0] = '\0';
    for (int i = 0; i < 3; i++) { wrongAttempts[i] = 0; probSolved[i] = false; }

    // Connect User class to GUI VFS instance
    AppUser::setGlobalVFS(&vfs);

    // Seed problems
    ProblemBank::getInstance()->seedProblems();

    initWidgets();
}
GUI::~GUI() {
    if (user) delete user;
    if (pendingUser) delete pendingUser;
}

// ════════════════════════════════════════════════════════════
//  Logic
// ════════════════════════════════════════════════════════════
void GUI::doLogin() {
    loginErr[0] = '\0';
    if (inpUser.empty()) { strcpy(loginErr, "Username cannot be empty"); return; }
    if (inpPass.empty()) { strcpy(loginErr, "Password cannot be empty"); return; }

    char profilePath[256];
    sprintf(profilePath, "codearena_users/%s/profile.txt", inpUser.val());

    {
        FILE* _chk = fopen(profilePath, "r");
        if (!_chk) {
            strcpy(loginErr, "Account not found. Please register first.");
            return;
        }
        fclose(_chk);
    }

    if (user) { delete user; user = nullptr; }
    user = new AppUser();
    user->deserialize(profilePath);

    if (!user->checkPassword(inpPass.val())) {
        strcpy(loginErr, "Wrong password. Try again.");
        delete user; user = nullptr;
        return;
    }
    if (!user->getIsVerified()) {
        strcpy(loginErr, "Account not verified. Use Verify tab.");
        delete user; user = nullptr;
        return;
    }

    session.login(user);
    inpUser.clear(); inpPass.clear();
    scr = SCR_DASHBOARD;
}

void GUI::doRegister() {
    regErr[0] = '\0';
    if (inpRegUser.empty())  { strcpy(regErr, "Username required");    return; }
    if (inpRegEmail.empty()) { strcpy(regErr, "Email required");       return; }
    if (inpRegPass.empty())  { strcpy(regErr, "Password required");    return; }

    // Check username has no spaces
    const char* u = inpRegUser.val();
    for (int i = 0; u[i]; i++) {
        if (u[i] == ' ') { strcpy(regErr, "Username cannot have spaces"); return; }
    }

    char profilePath[256];
    sprintf(profilePath, "codearena_users/%s/profile.txt", inpRegUser.val());
    {
        FILE* _chk = fopen(profilePath, "r");
        if (_chk) {
            fclose(_chk);
            strcpy(regErr, "Username already taken");
            return;
        }
    }

    if (pendingUser) { delete pendingUser; pendingUser = nullptr; }
    pendingUser = new AppUser(inpRegUser.val(), inpRegEmail.val(), inpRegPass.val());
    bool ok = pendingUser->registerUser(vfs);
    if (!ok) { strcpy(regErr, "Registration failed"); delete pendingUser; pendingUser = nullptr; return; }

    // Generate 6-digit token (hash of username)
    unsigned int h = 0;
    const char* un = inpRegUser.val();
    for (int i = 0; un[i]; i++) h = h*31 + un[i];
    int token6 = 100000 + (h % 900000);
    sprintf(pendingToken, "%d", token6);

    // Try sending email via mailx/sendmail (works on Linux with mailx installed)
    char mailCmd[512];
    sprintf(mailCmd,
        "echo 'Your CodeArena verification token is: %d\n\nUse this in the Verify tab.' | "
        "mail -s 'CodeArena Email Verification' '%s' 2>/dev/null || true",
        token6, inpRegEmail.val());
    system(mailCmd);

    // Show token in verify hint (fallback if email fails)
    sprintf(verifyHint, "Token sent! (If no email: %d)", token6);

    inpRegUser.clear(); inpRegEmail.clear(); inpRegPass.clear();
    tab = TAB_VERIFY;
}

void GUI::doVerify() {
    verifyErr[0] = '\0';
    if (!pendingUser) { strcpy(verifyErr, "Register first"); return; }
    if (inpToken.empty()) { strcpy(verifyErr, "Enter token (your username)"); return; }

    // Check 6-digit token first, fallback to username
    // Store username in local buffer FIRST — getUsername() returns MyString by value
    // calling .c_str() on a temporary is a dangling pointer → garbage username!
    MyString unameTemp = pendingUser->getUsername();
    const char* unameCStr = unameTemp.c_str();

    bool tokenOk = false;
    if (pendingToken[0] != '\0' && strcmp(inpToken.val(), pendingToken) == 0)
        tokenOk = true;
    else if (strcmp(inpToken.val(), unameCStr) == 0)
        tokenOk = true;

    if (!tokenOk) {
        strcpy(verifyErr, "Wrong token. Check your email.");
        return;
    }
    pendingUser->verify(unameCStr); // mark verified

    // Update disk file with verified=1
    char profilePath[256];
    sprintf(profilePath, "codearena_users/%s/profile.txt", unameCStr);
    pendingUser->serialize(profilePath);

    if (user) { delete user; user = nullptr; }
    user = pendingUser;
    pendingUser = nullptr;
    inpToken.clear();

    session.login(user);
    scr = SCR_DASHBOARD;
}

void GUI::doStartContest() {
    // Level -> difficulty and offset into that pool
    int diffMap[6]   = {0, 1, 1, 3, 3, 5};
    int offsetMap[6] = {0, 0, 2, 0, 2, 0};
    contestDiff   = diffMap[selectedDiff];
    contestOffset = offsetMap[selectedDiff];
    currentProb = 0;
    verdictSet  = false;
    verdictOk   = false;
    solvedCount = 0;
    finalScore  = 0;
    syntaxErr[0] = '\0';
    for (int i = 0; i < 3; i++) { wrongAttempts[i] = 0; probSolved[i] = false; }
    inpCode.clear();
    timerSecs    = 3600;
    timerElapsed = 0;
    clock.restart();
    scr = SCR_CONTEST;
}

void GUI::doSubmit() {
    if (probSolved[currentProb]) return;
    syntaxErr[0] = '\0';
    verdictSet = true;

    // ── Step 1: Basic empty check ──
    if (inpCode.bufLen == 0) {
        verdictOk = false;
        strcpy(syntaxErr, "// error: empty submission");
        return;
    }

    // ── Step 2: Real compile via g++ ──
    // Write code to temp file (with #include injected)
    {
        FILE* f = fopen("temp_check.cpp", "w");
        if (f) {
            // Inject headers if user hasn't included them
            bool hasInclude = false;
            for (int i = 0; i + 7 < inpCode.bufLen; i++) {
                if (inpCode.buf[i]=='#' && inpCode.buf[i+1]=='i') { hasInclude = true; break; }
            }
            if (!hasInclude) fprintf(f, "#include <iostream>\nusing namespace std;\n");
            fprintf(f, "%s", inpCode.buf);
            fclose(f);
        }
    }

    // Compile and capture stderr to file
    int ret = system("g++ -std=c++11 -fno-diagnostics-color -fsyntax-only temp_check.cpp 2>temp_err.txt");

    if (ret != 0) {
        // Read first error line from stderr
        FILE* ef = fopen("temp_err.txt", "r");
        if (ef) {
            char line[256]; line[0] = '\0';
            // Skip to first actual error line
            while (fgets(line, 255, ef)) {
                // Strip "temp_check.cpp:" prefix for cleaner display
                const char* colon = line;
                int colons = 0;
                for (int i = 0; line[i] && colons < 2; i++)
                    if (line[i] == ':') { colon = line + i; colons++; }
                if (colons >= 2) {
                    // Strip ANSI escape codes and non-ASCII chars from g++ output
                    const char* src = colon + 1;
                    int si = 0, di = 0;
                    char clean[480]; clean[0] = '\0';
                    while (src[si] && di < 478) {
                        if (src[si] == '\033' || (unsigned char)src[si] > 127) {
                            // Skip ANSI escape sequence \033[...m
                            if (src[si] == '\033' && src[si+1] == '[') {
                                si += 2;
                                while (src[si] && src[si] != 'm') si++;
                                if (src[si]) si++;  // skip 'm'
                            } else {
                                si++;  // skip non-ASCII byte
                            }
                        } else if (src[si] == '\n' || src[si] == '\r') {
                            break;  // stop at newline
                        } else {
                            clean[di++] = src[si++];
                        }
                    }
                    clean[di] = '\0';
                    snprintf(syntaxErr, 511, "// %s", clean);
                    break;
                }
            }
            fclose(ef);
            if (syntaxErr[0] == '\0') strcpy(syntaxErr, "// compile error");
        }
        remove("temp_check.cpp");
        remove("temp_err.txt");
        verdictOk = false;
        wrongAttempts[currentProb]++;
        return;
    }
    remove("temp_err.txt");

    // ── Step 3: Syntax OK — now run against test cases via Judge ──
    ProblemBank* bank = ProblemBank::getInstance();
    DynamicArray<Problem*> probs = bank->getByDifficulty(contestDiff);
    verdictOk = false;
    if (probs.size() > contestOffset + currentProb) {
        Problem* p = probs.get(contestOffset + currentProb);
        // Write full code for Judge
        FILE* f = fopen("temp_check.cpp", "w");
        if (f) {
            bool hasInclude = false;
            for (int i = 0; i + 7 < inpCode.bufLen; i++) {
                if (inpCode.buf[i]=='#' && inpCode.buf[i+1]=='i') { hasInclude = true; break; }
            }
            if (!hasInclude) fprintf(f, "#include <iostream>\nusing namespace std;\n");
            fprintf(f, "%s", inpCode.buf);
            fclose(f);
        }
        // Compile to binary
        int cret = system("g++ -std=c++11 temp_check.cpp -o temp_check_bin 2>/dev/null");
        if (cret == 0) {
            // Run all test cases
            Submission sub(inpCode.buf, currentProb, wrongAttempts[currentProb], timerElapsed);
            Judge judge;
            Verdict v = judge.evaluate(&sub, p);
            verdictOk = (v == ACCEPTED);
            if (!verdictOk && v == WRONG_ANSWER)
                strcpy(syntaxErr, "// Wrong Answer — output doesn't match expected");
        } else {
            strcpy(syntaxErr, "// compile error (runtime stage)");
        }
        remove("temp_check.cpp");
        remove("temp_check_bin");
    }
    if (verdictOk) {
        probSolved[currentProb] = true;
        solvedCount++;
        int diff = contestDiff;
        int penalty = wrongAttempts[currentProb] * 20;
        int timePenalty = (timerElapsed / 60) * 2;
        int sc = (diff * 100) - penalty - timePenalty;
        finalScore += (sc < 0 ? 0 : sc);
    } else {
        wrongAttempts[currentProb]++;
    }
}

void GUI::doEndContest() {
    if (finalScore > bestScore) bestScore = finalScore;
    totalSolvedAllTime += solvedCount;
    totalContests++;
    scr = SCR_RESULTS;
}

void GUI::updateTimer() {
    timerElapsed = (int)clock.getElapsedTime().asSeconds();
    if (timerElapsed >= timerSecs) {
        doEndContest();
    }
}

// ════════════════════════════════════════════════════════════
//  Draw: Login
// ════════════════════════════════════════════════════════════
void GUI::drawLogin() {
    win.clear(C::BG);

    // Grid background
    for (float x = 0; x < 1100; x += 40)
        line(x, 0, x, 700, sf::Color(30,30,30));
    for (float y = 0; y < 700; y += 40)
        line(0, y, 1100, y, sf::Color(30,30,30));

    // Glow
    sf::CircleShape glow(340);
    glow.setFillColor(sf::Color(230,57,70,12));
    glow.setPosition(480, -120);
    win.draw(glow);

    float cx = 325.f, cw = 450.f;

    // Logo centered over card
    {
        sf::Text t1 = txt("Code",  32, C::TEXT, 0, 0);
        sf::Text t2 = txt("Arena", 32, C::RED,  0, 0);
        float w1 = t1.getLocalBounds().width;
        float w2 = t2.getLocalBounds().width;
        float startX = cx + (cw - w1 - w2) / 2.f;
        t1.setPosition(startX, 130); win.draw(t1);
        t2.setPosition(startX + w1, 130); win.draw(t2);
    }
    ctxt("Online Judge Platform", 11, C::MUTED, cx + cw/2.f, 172);

    // Card: y=192. Register tab needs more height for 3 fields.
    int cardH = (tab == TAB_REGISTER) ? 330 : 295;
    rect(cx, 192, cw, cardH, C::SURF, C::BORDER, 1.f);

    // Tabs on card top edge (y=200, h=36 → bottom at 236)
    btnTabLogin .draw(win, tab == TAB_LOGIN);
    btnTabReg   .draw(win, tab == TAB_REGISTER);
    btnTabVerify.draw(win, tab == TAB_VERIFY);
    line(cx, 236, cx + cw, 236, C::BORDER);  // separator

    // Labels are drawn 12px above each input box
    if (tab == TAB_LOGIN) {
        // inputs at 256, 322; btn at 380
        win.draw(txt("USERNAME", 9, C::MUTED, cx+20, 244));
        inpUser.draw(win);
        win.draw(txt("PASSWORD", 9, C::MUTED, cx+20, 310));
        inpPass.draw(win);
        btnLogin.draw(win);
        if (loginErr[0])
            win.draw(txt(loginErr, 11, sf::Color(255,100,100), cx+20, 430));
        win.draw(txt("No account?  Go to Register tab", 10, C::MUTED, cx+20, 450));

    } else if (tab == TAB_REGISTER) {
        // inputs at 256(h=36), 314(h=36), 372(h=36); btn at 420(h=40)
        win.draw(txt("USERNAME", 9, C::MUTED, cx+20, 244));
        inpRegUser.draw(win);
        win.draw(txt("EMAIL",    9, C::MUTED, cx+20, 302));
        inpRegEmail.draw(win);
        win.draw(txt("PASSWORD", 9, C::MUTED, cx+20, 360));
        inpRegPass.draw(win);
        btnRegister.draw(win);
        if (regErr[0])
            win.draw(txt(regErr, 11, sf::Color(255,100,100), cx+20, 468));
        win.draw(txt("After register, go to Verify tab", 10, C::MUTED, cx+20, 486));

    } else {
        // Verify: input at 282(h=40), btn at 336(h=42)
        win.draw(txt("Enter your token (or username)", 11, C::TEXT,  cx+20, 252));
        win.draw(txt("TOKEN", 9, C::MUTED, cx+20, 270));
        inpToken.draw(win);
        btnVerify.draw(win);
        if (verifyErr[0])
            win.draw(txt(verifyErr,  11, sf::Color(255,100,100), cx+20, 388));
        if (verifyHint[0])
            win.draw(txt(verifyHint, 10, sf::Color(100,220,100), cx+20, 406));
    }

    win.display();
}

// ════════════════════════════════════════════════════════════
//  Draw: Dashboard
// ════════════════════════════════════════════════════════════
void GUI::drawDashboard() {
    win.clear(C::BG);

    // Navbar
    rect(0, 0, 1100, 58, C::SURF, C::BORDER, 1.f);
    {
        sf::Text t1 = txt("Code",  20, C::TEXT, 30, 16);
        float t1w = t1.getLocalBounds().width;
        sf::Text t2 = txt("Arena", 20, C::RED,  30 + t1w + 2, 16);
        win.draw(t1); win.draw(t2);
    }

    // Sanitize username to printable ASCII only
    char safeUname[64] = "guest";
    if (user) {
        // MUST store MyString in named variable — getUsername() returns by value
        // calling .c_str() on a temporary gives a dangling pointer after the statement
        MyString rawUname = user->getUsername();
        const char* raw = rawUname.c_str();
        int si = 0;
        for (int i = 0; raw[i] && si < 62; i++)
            if ((unsigned char)raw[i] >= 32 && (unsigned char)raw[i] < 127)
                safeUname[si++] = raw[i];
        safeUname[si] = '\0';
        if (si == 0) strcpy(safeUname, "user");
    }
    const char* uname = safeUname;
    char navStr[80]; sprintf(navStr, "// %s", uname);
    // Position username text with online dot — dot at 808, text after it
    sf::CircleShape dot(4);
    dot.setFillColor(C::GREEN);
    dot.setPosition(810, 25);
    win.draw(dot);
    win.draw(txt(navStr, 13, C::MUTED, 822, 19));

    btnLogout.draw(win);

    // Welcome
    char welcome[128]; sprintf(welcome, "Welcome back, %s", safeUname);
    win.draw(txt(welcome, 26, C::TEXT, 60, 86));
    win.draw(txt("// ready to grind some problems?", 12, C::MUTED, 60, 120));

    // Stat cards - dynamic values
    char cDone[8];  sprintf(cDone,  "%d",   totalContests);
    char cSolv[8];  sprintf(cSolv,  "%d",   totalSolvedAllTime);
    char cBest[8];  sprintf(cBest,  "%d",   bestScore);
    char cAccu[8];
    if (totalContests > 0 && totalSolvedAllTime > 0)
        sprintf(cAccu, "%d%%", (totalSolvedAllTime * 100) / (totalContests * 3));
    else
        sprintf(cAccu, "0%%");
    struct Stat { const char* label; const char* val; bool red; };
    Stat stats[] = {{"Contests Done",cDone,false},{"Problems Solved",cSolv,false},{"Best Score",cBest,true},{"Accuracy",cAccu,false}};
    for (int i = 0; i < 4; i++) {
        float sx = 60 + i * 254.f;
        rect(sx, 154, 234, 96, C::SURF, C::BORDER, 1.f);
        win.draw(txt(stats[i].label, 10, C::MUTED, sx+14, 168));
        win.draw(txt(stats[i].val,   26, stats[i].red ? C::RED : C::TEXT, sx+14, 196));
    }

    // Start section
    rect(60, 270, 980, 112, C::SURF, C::BORDER, 1.f);
    win.draw(txt("Start New Contest", 14, C::TEXT, 80, 280));
    line(80, 300, 1020, 300, C::BORDER);
    win.draw(txt("SELECT DIFFICULTY", 9, C::MUTED, 80, 308));
    for (int i = 0; i < 5; i++)
        btnDiff[i].draw(win, selectedDiff == i+1);
    btnStart.draw(win);

    // History section
    win.draw(txt("Contest History", 14, C::TEXT, 60, 400));
    line(60, 422, 1040, 422, C::BORDER);

    const char* hdr[] = {"Contest","Difficulty","Score","Solved","Result"};
    float hcols[] = {80, 280, 460, 590, 730};
    for (int i = 0; i < 5; i++)
        win.draw(txt(hdr[i], 10, C::MUTED, hcols[i], 430));

    struct Row { const char* c,*d,*s,*sv,*r; sf::Color rc; };
    Row rows[] = {
        {"Contest #3","Level 3","620","2/3","Partial",  C::YELLOW},
        {"Contest #2","Level 2","840","3/3","Completed",C::GREEN},
        {"Contest #1","Level 4","200","1/3","Failed",   C::RED}
    };
    for (int i = 0; i < 3; i++) {
        float ry = 458 + i*40.f;
        line(60, ry+38, 1040, ry+38, C::BORDER);
        win.draw(txt(rows[i].c,  13, C::TEXT, hcols[0], ry+8));
        win.draw(txt(rows[i].d,  13, C::TEXT, hcols[1], ry+8));
        win.draw(txt(rows[i].s,  13, C::TEXT, hcols[2], ry+8));
        win.draw(txt(rows[i].sv, 13, C::TEXT, hcols[3], ry+8));
        win.draw(txt(rows[i].r,  13, rows[i].rc, hcols[4], ry+8));
    }

    win.display();
}

// ════════════════════════════════════════════════════════════
//  Draw: Contest
// ════════════════════════════════════════════════════════════
void GUI::drawContest() {
    win.clear(C::BG);
    updateTimer();
    int remaining = timerSecs - timerElapsed;
    if (remaining < 0) remaining = 0;

    // Navbar
    rect(0, 0, 1100, 58, C::SURF, C::BORDER, 1.f);
    {
        sf::Text t1 = txt("Code",    16, C::TEXT, 20, 18);
        float _cw2 = t1.getLocalBounds().width;
        sf::Text t2 = txt("Arena",   16, C::RED,  20 + _cw2 + 2, 18);
        float _aw2 = t2.getLocalBounds().width;
        sf::Text t3 = txt("// contest", 10, C::MUTED, 20 + _cw2 + _aw2 + 10, 22);
        win.draw(t1); win.draw(t2); win.draw(t3);
    }

    // Timer
    int m = remaining/60, s = remaining%60;
    char tstr[16]; sprintf(tstr, "%02d:%02d", m, s);
    sf::Color tcol = remaining < 300 ? sf::Color(255,80,80) : C::RED;
    rect(480, 12, 140, 36, C::RED_GLO, tcol, 1.f);
    sf::Text tt = txt(tstr, 20, tcol, 0, 0);
    sf::FloatRect tlb = tt.getLocalBounds();
    tt.setPosition(550 - tlb.width/2.f - tlb.left, 12 + (36 - tlb.height)/2.f - tlb.top);
    win.draw(tt);

    btnEndContest.draw(win);

    // Left panel
    rect(0, 58, 420, 642, C::SURF, C::BORDER, 1.f);
    line(420, 58, 420, 700, C::BORDER);

    // Prob tabs
    for (int i = 0; i < 3; i++) {
        bool active = (currentProb == i);
        bool solved = probSolved[i];
        sf::Color lc = solved ? C::GREEN : (active ? C::RED : C::MUTED);
        btnProb[i].box.setFillColor(active ? sf::Color(30,5,8) : C::SURF);
        btnProb[i].box.setOutlineColor(active ? C::RED : C::BORDER);
        btnProb[i].label.setFillColor(lc);
        win.draw(btnProb[i].box);
        win.draw(btnProb[i].label);
    }
    line(0, 102, 420, 102, C::BORDER);

    // Problem content
    ProblemBank* bank = ProblemBank::getInstance();
    DynamicArray<Problem*> probs = bank->getByDifficulty(contestDiff);
    if (probs.size() > contestOffset + currentProb) {
        Problem* p = probs.get(contestOffset + currentProb);

        // Store ALL MyString returns in named locals — .c_str() on temporaries = dangling ptr!
        MyString probTitle = p->getTitle();
        MyString probDesc  = p->getDescription();

        win.draw(txt(probTitle.c_str(), 16, C::TEXT, 18, 116));

        char dstr[32]; sprintf(dstr, "Difficulty %d", p->getDifficulty());
        rect(18, 144, 100, 22, sf::Color(0,25,5), C::GREEN, 1.f);
        win.draw(txt(dstr, 9, C::GREEN, 22, 148));

        char tcstr[32]; sprintf(tcstr, "%d test cases", p->getTestCases().size());
        rect(128, 144, 96, 22, C::SURF2, C::BORDER, 1.f);
        win.draw(txt(tcstr, 9, C::MUTED, 132, 148));

        if (probSolved[currentProb]) {
            rect(234, 144, 80, 22, sf::Color(0,30,10), C::GREEN, 1.f);
            win.draw(txt("SOLVED", 9, C::GREEN, 244, 148));
        }

        // Description word wrap — using named local probDesc.c_str() (safe)
        {
            const char* desc = probDesc.c_str();
            int dlen = strlen(desc);
            float dy = 180;
            int lineStart = 0;
            while (lineStart < dlen && dy < 222) {
                int lineEnd = lineStart;
                int lastSpace = lineStart;
                while (lineEnd < dlen && lineEnd - lineStart < 44) {
                    if (desc[lineEnd] == '\n') break;
                    if (desc[lineEnd] == ' ') lastSpace = lineEnd;
                    lineEnd++;
                }
                if (lineEnd < dlen && desc[lineEnd] != '\n' && lastSpace > lineStart)
                    lineEnd = lastSpace;
                char lineBuf[64];
                int copyLen = lineEnd - lineStart;
                if (copyLen >= 63) copyLen = 63;
                strncpy(lineBuf, desc + lineStart, copyLen);
                lineBuf[copyLen] = '\0';
                win.draw(txt(lineBuf, 12, sf::Color(200,200,200), 18, dy));
                dy += 17;
                lineStart = lineEnd;
                if (lineStart < dlen && (desc[lineStart] == ' ' || desc[lineStart] == '\n'))
                    lineStart++;
            }
        }

        if (p->getTestCases().size() > 0) {
            // Store input/expected in named locals — same dangling ptr issue
            MyString exInput    = p->getTestCases().get(0).getInput();
            MyString exExpected = p->getTestCases().get(0).getExpected();
            // Draw example input — multi-line aware
            {
                const char* raw  = exInput.c_str();
                const char* rawE = exExpected.c_str();

                // Count lines in input
                int inLines = 1;
                for (int ci = 0; raw[ci]; ci++)
                    if (raw[ci] == '\n') inLines++;

                const float LINE_H = 17.f;
                const float BOX_PAD = 8.f;
                float inBoxH = inLines * LINE_H + BOX_PAD * 2;
                if (inBoxH < 32.f) inBoxH = 32.f;

                float inY  = 240.f;
                float outLabelY = inY + inBoxH + 8.f;
                float outY      = outLabelY + 14.f;

                // Draw input label + box
                win.draw(txt("EXAMPLE INPUT", 9, C::MUTED, 18, 228));
                rect(18, inY, 384, inBoxH, C::SURF2, C::BORDER, 1.f);

                // Draw each line of input
                {
                    float ly = inY + BOX_PAD;
                    int lineStart = 0;
                    int rlen = 0;
                    while (raw[rlen]) rlen++;
                    for (int ci = 0; ci <= rlen; ci++) {
                        if (raw[ci] == '\n' || raw[ci] == '\0') {
                            int segLen = ci - lineStart;
                            if (segLen > 44) segLen = 44;
                            char seg[48];
                            for (int k = 0; k < segLen; k++) seg[k] = raw[lineStart + k];
                            seg[segLen] = '\0';
                            win.draw(txt(seg, 12, C::TEXT, 28, ly));
                            ly += LINE_H;
                            lineStart = ci + 1;
                        }
                    }
                }

                // Draw expected output label + box (single line always)
                win.draw(txt("EXPECTED OUTPUT", 9, C::MUTED, 18, outLabelY));
                rect(18, outY, 384, 32, C::SURF2, C::BORDER, 1.f);
                // Truncate expected if too long
                char flatE[48]; int ei = 0;
                for (int ci = 0; rawE[ci] && ei < 44; ci++) {
                    if (rawE[ci] == '\n') break;
                    flatE[ei++] = rawE[ci];
                }
                flatE[ei] = '\0';
                win.draw(txt(flatE, 12, C::TEXT, 28, outY + 9));
            }
        }
    } else {
        win.draw(txt("No problems for this difficulty", 13, C::MUTED, 30, 200));
    }

    // Right panel - editor
    rect(420, 58, 680, 642, sf::Color(11,11,11), C::BORDER, 1.f);
    rect(420, 58, 680, 48, C::SURF, C::BORDER, 1.f);
    win.draw(txt("SOLUTION   C++", 10, C::MUTED, 440, 76));

    // ── Code editor with line numbers ──
    // Editor: y=106, height=482 → bottom at 588 (8px above footer at 596)
    rect(420, 106, 44, 482, sf::Color(14,14,14), C::BORDER, 1.f);
    inpCode.box.setPosition(464, 106);
    inpCode.box.setSize({626.f, 482.f});
    inpCode.box.setFillColor(sf::Color::Transparent);
    inpCode.box.setOutlineThickness(0);
    inpCode.draw(win);

    // Draw line numbers — LINE_H must match InputBox cursor LINE_H exactly
    {
        int lineNum = 1;
        // Get actual line height from font (same as cursor calculation)
        float LINE_H = font.getLineSpacing(14);  // charSize=14 matches InputBox
        float gy = 116.f;  // top of code area + padding
        for (int i = 0; i <= inpCode.bufLen && gy < 584; i++) {
            if (i == 0 || inpCode.buf[i-1] == '\n') {
                char lnStr[8]; sprintf(lnStr, "%d", lineNum++);
                sf::Text lnTxt = txt(lnStr, 11, sf::Color(60,60,60), 0, gy);
                float lnW = lnTxt.getLocalBounds().width;
                lnTxt.setPosition(460 - lnW - 4, gy);
                win.draw(lnTxt);
                gy += LINE_H;
            }
        }
    }

    // Footer
    rect(420, 596, 680, 104, C::SURF, C::BORDER, 1.f);
    line(420, 596, 1100, 596, C::BORDER);

    if (probSolved[currentProb]) {
        win.draw(txt("Accepted - all test cases passed", 12, C::GREEN, 440, 610));
    } else if (verdictSet) {
        if (syntaxErr[0] != '\0') {
            char errDisp[80];
            strncpy(errDisp, syntaxErr, 79); errDisp[79] = '\0';
            win.draw(txt(errDisp, 11, sf::Color(255,90,90), 440, 608));
            char wstr[48]; sprintf(wstr, "attempt %d", wrongAttempts[currentProb]);
            win.draw(txt(wstr, 10, C::MUTED, 440, 626));
        } else {
            char wstr[64]; sprintf(wstr, "// Wrong Answer -- attempt %d", wrongAttempts[currentProb]);
            win.draw(txt(wstr, 12, C::RED, 440, 612));
        }
    } else {
        win.draw(txt("// press Submit to run against test cases", 11, C::MUTED, 440, 612));
    }

    // Wrong attempts badge
    if (wrongAttempts[currentProb] > 0 && !probSolved[currentProb]) {
        char wa[32]; sprintf(wa, "  ✗ %d wrong  ", wrongAttempts[currentProb]);
        win.draw(txt(wa, 10, sf::Color(200,100,100), 440, 632));
    }

    btnSubmit.draw(win);

    win.display();
}

// ════════════════════════════════════════════════════════════
//  Draw: Results
// ════════════════════════════════════════════════════════════
void GUI::drawResults() {
    win.clear(C::BG);

    // Navbar
    rect(0, 0, 1100, 58, C::SURF, C::BORDER, 1.f);
    sf::Text t1 = txt("Code",  20, C::TEXT, 30, 16);
    float _t1w = t1.getLocalBounds().width;
    sf::Text t2 = txt("Arena", 20, C::RED,  30 + _t1w + 2, 16);
    win.draw(t1); win.draw(t2);

    // Header
    ctxt("*", 36, C::RED, 550, 78);
    ctxt("Contest Complete", 26, C::TEXT, 550, 122);
    ctxt("// here is how you did", 12, C::MUTED, 550, 158);

    // Score card
    rect(300, 188, 500, 164, C::RED_GLO, C::RED, 1.f);
    ctxt("FINAL SCORE", 10, C::MUTED, 550, 202);
    char scoreStr[16]; sprintf(scoreStr, "%d", finalScore);
    {
        sf::Text st = txt(scoreStr, 52, C::RED, 0, 0);
        sf::FloatRect slb = st.getLocalBounds();
        st.setPosition(550 - slb.width/2.f - slb.left, 226);
        win.draw(st);
    }

    // Breakdown row
    int timeUsed = timerElapsed;
    char solvedStr[16], timeStr[16], wrongStr[16];
    sprintf(solvedStr, "%d / 3", solvedCount);
    sprintf(timeStr,   "%02d:%02d", timeUsed/60, timeUsed%60);
    int totalWrong = 0;
    for (int i = 0; i < 3; i++) totalWrong += wrongAttempts[i];
    sprintf(wrongStr, "%d", totalWrong);

    struct BD { const char* lbl; const char* val; };
    BD bds[] = {{"SOLVED",solvedStr},{"TIME",timeStr},{"WRONG",wrongStr}};
    for (int i = 0; i < 3; i++) {
        float bx = 300 + i*167.f;
        rect(bx, 324, 160, 68, C::SURF, C::BORDER, 1.f);
        win.draw(txt(bds[i].lbl, 9,  C::MUTED, bx+10, 334));
        win.draw(txt(bds[i].val, 20, C::TEXT,  bx+10, 354));
    }

    // Table
    win.draw(txt("Problem Breakdown", 14, C::TEXT, 100, 410));
    line(100, 432, 1000, 432, C::BORDER);

    const char* hdr[] = {"Problem","Difficulty","Wrong Atts","Score","Verdict"};
    float hcols[] = {120, 360, 490, 640, 770};
    for (int i = 0; i < 5; i++)
        win.draw(txt(hdr[i], 10, C::MUTED, hcols[i], 438));

    ProblemBank* bank = ProblemBank::getInstance();
    DynamicArray<Problem*> probs = bank->getByDifficulty(contestDiff);
    for (int i = 0; i < 3 && i < probs.size(); i++) {
        float ry = 462 + i*40.f;
        line(100, ry+38, 1000, ry+38, C::BORDER);
        { MyString rt = probs.get(contestOffset + i)->getTitle(); win.draw(txt(rt.c_str(), 12, C::TEXT, hcols[0], ry+10)); }
        char dstr[4]; sprintf(dstr, "%d", probs.get(contestOffset + i)->getDifficulty());
        win.draw(txt(dstr, 12, C::TEXT, hcols[1], ry+10));
        char wastr[4]; sprintf(wastr, "%d", wrongAttempts[i]);
        win.draw(txt(wastr, 12, C::TEXT, hcols[2], ry+10));
        int sc = probSolved[i] ? (probs.get(contestOffset + i)->getDifficulty()*100 - wrongAttempts[i]*20) : 0;
        char scstr[16]; sprintf(scstr, "%d", sc < 0 ? 0 : sc);
        win.draw(txt(scstr, 12, C::TEXT, hcols[3], ry+10));
        bool acc = probSolved[i];
        win.draw(txt(acc ? "Accepted" : "Not Solved", 12, acc ? C::GREEN : C::RED, hcols[4], ry+10));
    }

    btnBackDash.draw(win);
    win.display();
}

// ════════════════════════════════════════════════════════════
//  Event handlers
// ════════════════════════════════════════════════════════════
void GUI::evLogin(sf::Event& e) {
    sf::Vector2f mp = (sf::Vector2f)sf::Mouse::getPosition(win);
    if (e.type == sf::Event::MouseButtonPressed && e.mouseButton.button == sf::Mouse::Left) {
        // Focus management
        inpUser.focused    = inpUser.box.getGlobalBounds().contains(mp);
        inpPass.focused    = inpPass.box.getGlobalBounds().contains(mp);
        inpRegUser.focused = inpRegUser.box.getGlobalBounds().contains(mp);
        inpRegEmail.focused= inpRegEmail.box.getGlobalBounds().contains(mp);
        inpRegPass.focused = inpRegPass.box.getGlobalBounds().contains(mp);
        inpToken.focused   = inpToken.box.getGlobalBounds().contains(mp);

        if (btnTabLogin .contains(mp)) { tab = TAB_LOGIN;    loginErr[0]='\0'; }
        if (btnTabReg   .contains(mp)) { tab = TAB_REGISTER; regErr[0]='\0'; }
        if (btnTabVerify.contains(mp)) { tab = TAB_VERIFY;   verifyErr[0]='\0'; }

        if (tab == TAB_LOGIN    && btnLogin   .contains(mp)) doLogin();
        if (tab == TAB_REGISTER && btnRegister.contains(mp)) doRegister();
        if (tab == TAB_VERIFY   && btnVerify  .contains(mp)) doVerify();
    }
    if (e.type == sf::Event::KeyPressed && e.key.code == sf::Keyboard::Return) {
        if (tab == TAB_LOGIN)    doLogin();
        if (tab == TAB_REGISTER) doRegister();
        if (tab == TAB_VERIFY)   doVerify();
    }
    if (tab == TAB_LOGIN)    { inpUser.handleEvent(e); inpPass.handleEvent(e); }
    if (tab == TAB_REGISTER) { inpRegUser.handleEvent(e); inpRegEmail.handleEvent(e); inpRegPass.handleEvent(e); }
    if (tab == TAB_VERIFY)   { inpToken.handleEvent(e); }
}

void GUI::evDashboard(sf::Event& e) {
    sf::Vector2f mp = (sf::Vector2f)sf::Mouse::getPosition(win);
    if (e.type == sf::Event::MouseButtonPressed && e.mouseButton.button == sf::Mouse::Left) {
        for (int i = 0; i < 5; i++)
            if (btnDiff[i].contains(mp)) selectedDiff = i+1;
        if (btnStart .contains(mp)) doStartContest();
        if (btnLogout.contains(mp)) {
            session.logout();
            if (user) { delete user; user = nullptr; }
            scr = SCR_LOGIN;
            tab = TAB_LOGIN;
        }
    }
}

void GUI::evContest(sf::Event& e) {
    sf::Vector2f mp = (sf::Vector2f)sf::Mouse::getPosition(win);
    if (e.type == sf::Event::MouseButtonPressed && e.mouseButton.button == sf::Mouse::Left) {
        inpCode.focused = inpCode.box.getGlobalBounds().contains(mp);
        for (int i = 0; i < 3; i++) {
            if (btnProb[i].contains(mp)) {
                currentProb = i;
                verdictSet  = false;
                inpCode.clear();
            }
        }
        if (btnSubmit    .contains(mp)) doSubmit();
        if (btnEndContest.contains(mp)) doEndContest();
    }
    inpCode.handleEvent(e);
}

void GUI::evResults(sf::Event& e) {
    sf::Vector2f mp = (sf::Vector2f)sf::Mouse::getPosition(win);
    if (e.type == sf::Event::MouseButtonPressed && e.mouseButton.button == sf::Mouse::Left) {
        if (btnBackDash.contains(mp)) scr = SCR_DASHBOARD;
    }
}

// ════════════════════════════════════════════════════════════
//  Run loop
// ════════════════════════════════════════════════════════════
void GUI::run() {
    while (win.isOpen()) {
        sf::Event e;
        while (win.pollEvent(e)) {
            if (e.type == sf::Event::Closed) win.close();
            switch (scr) {
                case SCR_LOGIN:     evLogin(e);     break;
                case SCR_DASHBOARD: evDashboard(e); break;
                case SCR_CONTEST:   evContest(e);   break;
                case SCR_RESULTS:   evResults(e);   break;
            }
        }
        switch (scr) {
            case SCR_LOGIN:     drawLogin();     break;
            case SCR_DASHBOARD: drawDashboard(); break;
            case SCR_CONTEST:   drawContest();   break;
            case SCR_RESULTS:   drawResults();   break;
        }
    }
}