#include "SharedInterfaces.h"
#include <iostream>
using namespace std;

Submission::Submission()
{
    code = "";
    attemptNumber = 0;
    timeTakenSeconds = 0;
    problemId = 0;

    verdict = PENDING;
   }

Submission::Submission(const char* code, int problemId, int attempt, int timeTaken)
{
this->code = code;
this->problemId = problemId;
attemptNumber = attempt;
timeTakenSeconds = timeTaken;

verdict = PENDING;
}

MyString Submission::getCode() const
{
    return code;
}

Verdict  Submission::getVerdict() const
{
            return verdict;
}

int Submission::getAttempt() const
{
    return attemptNumber;
}

int Submission::getTimeTaken() const
{
    return timeTakenSeconds;
}

int Submission::getProblemId() const
{
    return problemId;
}

void Submission::setVerdict(Verdict v)
{
     verdict = v;
}