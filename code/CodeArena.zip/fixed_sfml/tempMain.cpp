#include <iostream>
#include "SharedInterfaces.h"
#include "25i-6601_Helper.h"

int main()
{
    VFSAdapter vfs;

    // test 1: create directories
    vfs.createDir(MyString("/users"));
    vfs.createDir(MyString("/users/abd"));

    // test 2: write a file
    vfs.writeFile(MyString("/users/abd/code.cpp"), MyString("int main() { return 0; }"));

    // test 3: read it back
    MyString content = vfs.readFile(MyString("/users/abd/code.cpp"));
    std::cout << "Content: " << content.c_str() << std::endl;
    // should print: Content: int main() { return 0; }

    // test 4: exists
    std::cout << "Exists code.cpp: " << vfs.exists(MyString("/users/abd/code.cpp")) << std::endl;  // 1
    std::cout << "Exists fake.cpp: " << vfs.exists(MyString("/users/abd/fake.cpp")) << std::endl;  // 0

    // test 5: overwrite file
    vfs.writeFile(MyString("/users/abd/code.cpp"), MyString("int main() { return 1; }"));
    MyString updated = vfs.readFile(MyString("/users/abd/code.cpp"));
    std::cout << "Updated: " << updated.c_str() << std::endl;
    // should print: Updated: int main() { return 1; }

    // test 6: delete directory
    vfs.deleteDir(MyString("/users/abd"));
    std::cout << "Exists after delete: " << vfs.exists(MyString("/users/abd")) << std::endl;  // 0

    return 0;
}