#include "25i-6601_MountPoint.h"
#include <iostream>
using namespace std;

// Default constructor
MountPoint::MountPoint() : Directory()
{
    mountedPartition = nullptr;
}

// Parameterized constructor
MountPoint::MountPoint(const char* n, const char* created, User* o, Directory* p)
: Directory(n, created, o, p)
{
    mountedPartition = nullptr;
}

// Destructor
// we Dont delete mountedPartition, we dont own it
MountPoint::~MountPoint()
{
    
}

// Attaches a partition to this mount point
void MountPoint::mountPartition(Partition* p)
{
    mountedPartition = p;
    cout<<"Partion mounted...\n";
}

// Detaches the currently mounted partition
void MountPoint::unmountPartition()
{
    mountedPartition = nullptr;
    cout<<"Partition unmounted...\n";
}

// Returns true if mountedPartition is not nullptr
bool MountPoint::hasMounted()
{
    if(mountedPartition!=nullptr)
    return true;

    else
    return false;
}

// Prints mount point info including which partition is mounted
void MountPoint::display()
{
    Directory::display();       // prints directory info, children, size from Directory

    if(hasMounted())
        cout << "Mounted Partition: " << mountedPartition->label << endl;
    else
        cout << "No partition mounted\n";
}