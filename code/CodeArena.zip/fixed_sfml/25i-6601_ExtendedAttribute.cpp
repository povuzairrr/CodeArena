#include "25i-6601_ExtendedAttribute.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
ExtendedAttribute::ExtendedAttribute()
{
    key = new char[1];
    strcpy(key, "");

    value = new char[1];
    strcpy(value, "");
} 

// Parameterized constructor
ExtendedAttribute::ExtendedAttribute(const char* k, const char* v)
{
    int lenKey = strlen(k) + 1;

    key = new char[lenKey];
    strcpy(key, k);

    int lenVal = strlen(v) + 1;

    value = new char[lenVal];
    strcpy(value, v);
}

// Copy constructor
ExtendedAttribute& ExtendedAttribute::operator=(const ExtendedAttribute& other)
{
    if(this == &other)
        return *this;

    delete[] key;
    delete[] value;

    key = new char[strlen(other.key) + 1];
    strcpy(key, other.key);

    value = new char[strlen(other.value) + 1];
    strcpy(value, other.value);

    return *this;
}

// Destructor
ExtendedAttribute::~ExtendedAttribute()
{
    delete[] key;
    delete[] value;
}

// prints in format  Key : Value
void ExtendedAttribute::display()
{
    cout<<key<<" : "<<value<<endl;
}