#include "25i-6601_User.h"
#include <iostream>
#include "25i-6601_Helper.h"
using namespace std;

// Default constructor
User::User()
{
    role = STANDARD;
    userID = 0;

    username = new char[8];
    strcpy(username, "unknown");

    homePath = new char[14];
    strcpy(homePath, "/home/unknown");
}

// Parameterized constructor
User::User(const char* uname, int uid, const char* path, int r)
{
    if(uname == NULL || strlen(uname) == 0)
    {
        username = new char[8];
        strcpy(username, "unknown");
    }
    else
    {
        username = new char[strlen(uname) + 1];
        strcpy(username, uname);
    }

    if(uid < 0)
        userID = 0;
    else
        userID = uid;

    if(path == NULL || strlen(path) == 0)
    {
        homePath = new char[14];
        strcpy(homePath, "/home/unknown");
    }
    else
    {
        homePath = new char[strlen(path) + 1];
        strcpy(homePath, path);
    }

    role = r;
}

// Destructor
User::~User()
{
    delete[] username;
    delete[] homePath;
}

bool User::isAdmin()
{
    return role == ADMIN;
}

void User::display()
{
    cout << "Username: " << username << endl;
    cout << "User ID: " << userID << endl;
    cout << "Home Path: " << homePath << endl;
    cout << "Role: " << (role == ADMIN ? "Admin" : "Standard") << endl;
}