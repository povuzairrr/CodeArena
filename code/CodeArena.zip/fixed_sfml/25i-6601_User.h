#ifndef USER_H
#define USER_H

const int STANDARD = 0;
const int ADMIN    = 1;   // this will decide if the user is an admin or a normal user

class User {
public:
    char* username;
    char* homePath;
    int userID;
    int role;

    User();
    User(const char* uname, int uid, const char* path, int r);
    ~User();

    bool isAdmin();
    void display();
};

#endif