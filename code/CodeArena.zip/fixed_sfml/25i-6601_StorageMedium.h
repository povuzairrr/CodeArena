#ifndef STORAGEMEDIUM_H
#define STORAGEMEDIUM_H

const int HDD     = 0;
const int SSD     = 1;
const int OPTICAL = 2;

class StorageMedium {
public:
    char* name;
    float totalCapacity;        // in megabytes
    float usedCapacity;         // in megabytes
    int mediaType;
    bool isMounted;

    StorageMedium();
    StorageMedium(const char* n, float capacity, int type);
    ~StorageMedium();

    float getAvailableSpace();
    void mount();
    void unmount();
    void display();
};

#endif