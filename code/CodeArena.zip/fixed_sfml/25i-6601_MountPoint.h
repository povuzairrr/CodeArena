#ifndef MOUNTPOINT_H
#define MOUNTPOINT_H

#include "25i-6601_Directory.h"
#include "25i-6601_Partition.h"

class MountPoint : public Directory {
public:
    Partition* mountedPartition;    // aggregation, we dont own this partition

    MountPoint();
    MountPoint(const char* n, const char* created, User* o, Directory* p);
    ~MountPoint();

    void mountPartition(Partition* p);  
    void unmountPartition();            
    bool hasMounted();                  

    void display();                     
};

#endif