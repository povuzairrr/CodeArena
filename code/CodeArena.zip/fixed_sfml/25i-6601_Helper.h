#ifndef HELPER_H
#define HELPER_H

inline int strlen(const char* str)
{
    if (str == nullptr) return 0;
    int len = 0;
    while (str[len] != '\0') len++;
    return len;
}

inline void strcpy(char* dest, const char* src)
{
    if (dest == nullptr || src == nullptr) return;
    int i = 0;
    while (src[i] != '\0') { dest[i] = src[i]; i++; }
    dest[i] = '\0';
}

inline void strncpy(char* dest, const char* src, int n)
{
    if (dest == nullptr || src == nullptr || n <= 0) return;
    int i = 0;
    while (i < n - 1 && src[i] != '\0') { dest[i] = src[i]; i++; }
    dest[i] = '\0';
}

inline int strcmp(const char* a, const char* b)
{
    if (a == nullptr || b == nullptr) return -1;
    int i = 0;
    while (a[i] != '\0' && b[i] != '\0')
    {
        if (a[i] != b[i]) return a[i] - b[i];
        i++;
    }
    return a[i] - b[i];
}

inline void strcat(char* dest, const char* src)
{
    if (dest == nullptr || src == nullptr) return;
    int i = strlen(dest);
    int j = 0;
    while (src[j] != '\0') { dest[i] = src[j]; i++; j++; }
    dest[i] = '\0';
}

// returns index of first occurrence of c in str, -1 if not found
inline int strchr(const char* str, char c)
{
    if (str == nullptr) return -1;
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == c) return i;
    return -1;
}

// returns index of last occurrence of c in str, -1 if not found
inline int strrchr(const char* str, char c)
{
    if (str == nullptr) return -1;
    int last = -1;
    for (int i = 0; str[i] != '\0'; i++)
        if (str[i] == c) last = i;
    return last;
}

// returns true if pattern exists anywhere inside str
inline bool strcontains(const char* str, const char* pattern)
{
    if (str == nullptr || pattern == nullptr) return false;
    int strL = strlen(str);
    int patL = strlen(pattern);
    for (int i = 0; i <= strL - patL; i++)
    {
        int j = 0;
        while (j < patL && str[i + j] == pattern[j]) j++;
        if (j == patL) return true;
    }
    return false;
}

// copies substring of str from index start, length len into dest
inline void substr(char* dest, const char* str, int start, int len)
{
    if (dest == nullptr || str == nullptr) return;
    int i = 0;
    while (i < len && str[start + i] != '\0') { dest[i] = str[start + i]; i++; }
    dest[i] = '\0';
}

// converts int to char* — writes into dest, returns dest
inline char* intToStr(int num, char* dest)
{
    if (dest == nullptr) return nullptr;
    if (num == 0) { dest[0] = '0'; dest[1] = '\0'; return dest; }

    bool negative = num < 0;
    if (negative) num = -num;

    char temp[32];
    int i = 0;
    while (num > 0) { temp[i++] = '0' + (num % 10); num /= 10; }
    if (negative) temp[i++] = '-';

    int j = 0;
    for (int k = i - 1; k >= 0; k--) dest[j++] = temp[k];
    dest[j] = '\0';
    return dest;
}

// converts char* to int
inline int strToInt(const char* str)
{
    if (str == nullptr) return 0;
    int result = 0, i = 0, sign = 1;
    if (str[0] == '-') { sign = -1; i = 1; }
    while (str[i] != '\0') { result = result * 10 + (str[i] - '0'); i++; }
    return result * sign;
}

inline char toLower(char c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
inline char toUpper(char c) { return (c >= 'a' && c <= 'z') ? c - 32 : c; }
inline bool isDigit(char c) { return c >= '0' && c <= '9'; }
inline bool isAlpha(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); }
inline bool isSpace(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r'; }

// trims leading and trailing whitespace into dest
inline void strtrim(char* dest, const char* src)
{
    if (dest == nullptr || src == nullptr) return;
    int start = 0;
    while (isSpace(src[start])) start++;
    int end = strlen(src) - 1;
    while (end > start && isSpace(src[end])) end--;
    substr(dest, src, start, end - start + 1);
}

#endif