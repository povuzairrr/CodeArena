#ifndef SYMBOLICLINK_H
#define SYMBOLICLINK_H

#include "25i-6601_FSEntity.h"

class SymbolicLink : public FSEntity {
public:
    FSEntity* target;           // aggregation, we dont own this, target lives independently

    SymbolicLink();
    SymbolicLink(const char* n, const char* created, User* o, FSEntity* t);
    ~SymbolicLink();

    bool isDangling();          
    void setTarget(FSEntity* t);
    FSEntity* getTarget();      

    void display();             
    int getSize();              
};

#endif