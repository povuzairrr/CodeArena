#!/bin/bash
echo "Compiling CodeArena..."
g++ -std=c++14 -o codearena \
  main.cpp GUI.cpp \
  MyString.cpp VFSAdapter.cpp User.cpp Session.cpp \
  Problem.cpp ProblemBank.cpp TestCase.cpp Submission.cpp \
  Judge.cpp Contest.cpp EasyContest.cpp MediumContest.cpp HardContest.cpp \
  25i-6601_FSEntity.cpp 25i-6601_File.cpp 25i-6601_Directory.cpp \
  25i-6601_Volume.cpp 25i-6601_Permission.cpp 25i-6601_User.cpp \
  25i-6601_StorageMedium.cpp 25i-6601_ExtendedAttribute.cpp \
  25i-6601_VersionRecord.cpp 25i-6601_SymbolicLink.cpp \
  25i-6601_MountPoint.cpp 25i-6601_Partition.cpp \
  -lsfml-graphics -lsfml-window -lsfml-system
if [ $? -eq 0 ]; then
    echo "Build successful! Run: ./codearena"
else
    echo "Build failed."
fi
