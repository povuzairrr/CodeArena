#ifndef VERSIONRECORD_H
#define VERSIONRECORD_H

#include "25i-6601_User.h"

class VersionRecord {
public:
    char* content;       // the old content before the edit
    char* timestamp;     // when the edit was made
    User* editedBy;      // who made the edit, pointer only, we dont own this user

    VersionRecord();
    VersionRecord(const char* oldContent, const char* time, User* user);
    ~VersionRecord();

    void display();
};

#endif