#include "25i-6601_File.h"
#include <iostream>
#include "25i-6601_Helper.h"
#include<ctime>
using namespace std;

// Default constructor
File::File() : FSEntity()
{
    content = new char[1];
    strcpy(content, "");

    size = 0;

    versionHistory = nullptr;
    
    versionCount = 0;
}

// Parameterized constructor
File::File(const char* n, const char* created, User* o, const char* fileContent)
: FSEntity(n, created, o, FILE_TYPE)
{
    content = new char[strlen(fileContent) + 1];
    strcpy(content, fileContent);

    size = strlen(content);

    versionHistory = nullptr;
    versionCount = 0;
}



// Destructor
File::~File()
{
    delete[] content;
    delete[] versionHistory;
}



// Modifies the file content
void File::setContent(const char* newContent, User* editedBy)
{
    // save old content into a new VersionRecord before overwriting
    VersionRecord* newHistory = new VersionRecord[versionCount + 1];

    for(int i = 0; i < versionCount; i++)
    {
        newHistory[i] = versionHistory[i];
    }

    //time
    time_t now = time(0);
    char* currentTime = ctime(&now);

    // save current content before overwriting
    newHistory[versionCount] = VersionRecord(content, currentTime, editedBy);

    delete[] versionHistory;
    versionHistory = newHistory;
    versionCount++;


    delete[] content;
    content = new char[strlen(newContent) + 1];
    strcpy(content, newContent);

    
    size = strlen(content);

    delete[] lastModified;
    lastModified = new char[strlen(currentTime) + 1];
    strcpy(lastModified, currentTime);
}


void File::displayHistory()
{
    if(versionCount == 0)
    {
        cout<<"No Version history...\n";
        return;
    }

    for(int i=0; i<versionCount; i++)
    {
        versionHistory[i].display();
    }
}



// Prints full file info including content and version count
void File::display()
{
    displayInfo();                              // prints name, owner, timestamps, permissions from FSEntity
    cout << "Content: " << content << endl;
    cout << "Size: " << size << " characters" << endl;
    cout << "Versions saved: " << versionCount << endl;
    displayAttributes();                        // prints extended attributes from FSEntity
}



// Returns the size of the file content in characters
int File::getSize()
{
    return size;
}