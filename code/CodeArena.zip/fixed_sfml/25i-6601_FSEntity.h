#ifndef FSENTITY_H
#define FSENTITY_H

#include "25i-6601_Permission.h"
#include "25i-6601_User.h"
#include "25i-6601_ExtendedAttribute.h"

const int FILE_TYPE       = 0;
const int DIRECTORY_TYPE  = 1;
const int SYMLINK_TYPE    = 2;
const int MOUNTPOINT_TYPE = 3;

class FSEntity {
public:
    char* name;
    char* createdAt;
    char* lastModified;
    User* owner;                            // aggregation, we dont own the user
    Permission permission;                  // composition, permission lives and dies with entity
    ExtendedAttribute* attributes;         
    int attributeCount;
    int type;

    FSEntity();
    FSEntity(const char* n, const char* created, User* o, int t);
    virtual ~FSEntity();

    void addAttribute(const char* key, const char* value);
    void displayAttributes();
    void displayInfo();

    virtual void display() = 0;            // pure virtual, every subclass must implement this
    virtual int getSize() = 0;             // pure virtual, every subclass must implement this
};                                         
                                            /*The Two Effects of = 0
                                            1. Makes FSEntity abstract — you can never do FSEntity e; directly
                                            2. Forces every subclass to implement display() and getSize() or it won't compile*/

#endif