#ifndef PARTITION_H
#define PARTITION_H

#include "25i-6601_StorageMedium.h"

const int FAT32 = 0;
const int NTFS  = 1;
const int EXT4  = 2;

class Partition {
public:
    char* label;
    float allocatedCapacity;    
    float usedSpace;            
    int formatType;
    StorageMedium* medium;      // aggregation, we dont own this, medium owns us

    Partition();
    Partition(const char* l, float capacity, int format, StorageMedium* m);
    ~Partition();

    float getAvailableSpace();
    bool canFit(float sizeMB);  
    void display();
};

#endif