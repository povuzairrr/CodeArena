#include "25i-6601_Permission.h"
#include <iostream>
using namespace std;

// Constructor
// set all to false by default
Permission::Permission()
{
    ownerRead = false;
    ownerWrite = false;
    ownerExecute = false;

    groupRead = false;
    groupWrite = false;
    groupExecute = false;

    othersRead = false;
    othersWrite = false;
    othersExecute = false;
}

// Setters
void Permission::setOwner(bool r, bool w, bool x)
{
    ownerRead = r;
    ownerWrite = w;
    ownerExecute = x;
}

void Permission::setGroup(bool r, bool w, bool x)
{
    groupRead = r;
    groupWrite = w;
    groupExecute = x;
}

void Permission::setOthers(bool r, bool w, bool x)
{
    othersRead = r;
    othersWrite = w;
    othersExecute = x;
}

// Checkers
bool Permission::canOwnerRead()
{
    if(ownerRead)
    return true;

    else
    return false;
}

bool Permission::canOwnerWrite()
{
    if(ownerWrite)
    return true;

    else
    return false;
}

bool Permission::canOwnerExecute()
{
    if(ownerExecute)
    return true;

    else
    return false;
}

bool Permission::canGroupRead()
{
    if(groupRead)
    return true;

    else
    return false;
}

bool Permission::canGroupWrite()
{
    if(groupWrite)
    return true;

    else
    return false;
}

bool Permission::canGroupExecute()
{
    if(groupExecute)
    return true;

    else
    return false;
}

bool Permission::canOthersRead()
{
    if(othersRead)
    return true;

    else
    return false;
}

bool Permission::canOthersWrite()
{
    if(othersWrite)
    return true;

    else
    return false;
}

bool Permission::canOthersExecute()
{
    if(othersExecute)
    return true;

    else
    return false;
}

// Display
//print rwxrwxrwx format
void Permission::display()
{
    cout << (ownerRead ? "r" : "-");
    cout << (ownerWrite ? "w" : "-");
    cout << (ownerExecute ? "x" : "-");
    cout << (groupRead ? "r" : "-");
    cout << (groupWrite ? "w" : "-");
    cout << (groupExecute ? "x" : "-");
    cout << (othersRead ? "r" : "-");
    cout << (othersWrite ? "w" : "-");
    cout << (othersExecute ? "x" : "-")<<endl;
}