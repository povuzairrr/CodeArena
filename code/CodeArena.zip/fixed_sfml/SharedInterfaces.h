#ifndef SHARED_INTERFACES_H
#define SHARED_INTERFACES_H

#include "25i-6601_Directory.h"
#include "25i-6601_File.h"
#include "25i-6601_Helper.h"


enum Verdict {
    ACCEPTED,
    WRONG_ANSWER,
    COMPILE_ERROR,
    RUNTIME_ERROR,
    PENDING
};

enum Difficulty {
    EASY   = 1,
    MEDIUM = 3,
    HARD   = 5
};

// ────────────────────────────────────────────────────────────
//  INTERFACE: Persistable
//  Any class that saves/loads from VFS must implement this.
//  Person 2: User, Problem must implement this.
//  Abd: Contest must implement this.
// ────────────────────────────────────────────────────────────

class Persistable {
public:
    virtual void serialize(const char* path)   = 0;
    virtual void deserialize(const char* path) = 0;
    virtual ~Persistable() {}
};

// ────────────────────────────────────────────────────────────
//  INTERFACE: Evaluatable
//  Only Judge implements this.
// ────────────────────────────────────────────────────────────

// Forward declarations so interfaces can reference each other
class Submission;
class Problem;

class Evaluatable {
public:
    virtual Verdict evaluate(Submission* s, Problem* p) = 0;
    virtual ~Evaluatable() {}
};

// ────────────────────────────────────────────────────────────
//  MyString  —  replaces std::string everywhere
//  Abd builds this. Everyone uses it.
//  RULE: Never use char[] directly in your class members.
//        Always use MyString.
// ────────────────────────────────────────────────────────────

class MyString {
private:
    char* data;
    int   len;
public:
    MyString();
    MyString(const char* str);
    MyString(const MyString& other);        // deep copy
    MyString& operator=(const MyString& other);
    MyString& operator=(const char* str);
    bool      operator==(const MyString& other) const;
    bool      operator!=(const MyString& other) const;
    MyString  operator+(const MyString& other) const;

    const char* c_str()   const;
    int         length()  const;
    bool        isEmpty() const;

    ~MyString();
};

// ────────────────────────────────────────────────────────────
//  DynamicArray<T>  —  replaces std::vector everywhere
//  Abd builds this. Everyone uses it.
// ────────────────────────────────────────────────────────────

template<typename T>
class DynamicArray {
private:
    T*  data;
    int sz;
    int cap;
    void resize()
    {
        cap *= 2;
        T* newData = new T[cap];
        for (int i = 0; i < sz; i++)
            newData[i] = data[i];

        delete[] data;
        data = newData;
    }
public:
    DynamicArray()
    {
        cap = 4;
        sz = 0;
        data = new T[cap];
    }

    DynamicArray(const DynamicArray& other)
    {
        data = new T[other.cap];
        this->cap = other.cap;
        this->sz = other.sz;

        for(int i=0; i<sz; i++)
        {
            this->data[i] = other.data[i];
        }
    }

    DynamicArray& operator=(const DynamicArray& other)
    {
        if (this == &other)
        {
          return *this;
        }

        delete[] data;
        cap = other.cap;
        data = new T[other.cap];
        this->cap = other.cap;
        this->sz = other.sz;

        for(int i=0; i<sz; i++)
        {
            this->data[i] = other.data[i];
        }
        return *this;
    }

    void push(const T& item)
    {
        if(sz==cap)
        {
            resize();
        }

        data[sz] = item;

        sz++;
    }

    T&   get(int index)
    {
        return data[index];
    }

    void remove(int index)
    {
        for (int i = index; i < sz - 1; i++)
            data[i] = data[i + 1];
        sz--;
    }

    int  size() const
    {
        return sz;
    }

    bool isEmpty() const
    {
        if(sz == 0)
        return true;

        else
        return false;
    }

    void clear()
    {
        sz = 0;
    }

    ~DynamicArray()
    {
        delete[] data;
    }
};

// ────────────────────────────────────────────────────────────
//  HashMap<K,V>  —  replaces std::map everywhere
//  Abd builds this. Everyone uses it.
//  Used by ProblemBank (Person 2) and Session.
// ────────────────────────────────────────────────────────────

template<typename K, typename V>
class HashMap {
private:
    struct Node {
        K     key;
        V     value;
        Node* next;
        Node(const K& k, const V& v) : key(k), value(v), next(nullptr) {}
    };

    Node** buckets;
    int    capacity;
    int    count;

    int hash(const K& key) const
    {
        int sum = 0;
        const char* str = key.c_str();
        for (int i = 0; str[i] != '\0'; i++)
            sum += str[i];
        return sum % capacity;
    }

public:
    HashMap(int cap = 64)
    {
        capacity = cap;
        count = 0;
        buckets = new Node*[capacity];
        for (int i = 0; i < capacity; i++)
            buckets[i] = nullptr;
    }

    void insert(const K& key, const V& value)
    {
        int index = hash(key);

        
        Node* current = buckets[index];
        while (current != nullptr)
        {
            if (current->key == key)
            {
                current->value = value;
                return;
            }
            current = current->next;
        }

        
        Node* newNode = new Node(key, value);
        newNode->next = buckets[index];
        buckets[index] = newNode;
        count++;
    }

    V& get(const K& key)
    {
        int index = hash(key);
        Node* current = buckets[index];
        while (current != nullptr)
        {
            if (current->key == key)
                return current->value;
            current = current->next;
        }
    }

    bool contains(const K& key) const
    {
        int index = hash(key);
        Node* current = buckets[index];
        while (current != nullptr)
        {
            if (current->key == key)
                return true;
            current = current->next;
        }
        return false;
    }

    void remove(const K& key)
    {
        int index = hash(key);
        Node* current = buckets[index];
        Node* prev = nullptr;

        while (current != nullptr)
        {
            if (current->key == key)
            {
                if (prev == nullptr)
                    buckets[index] = current->next;
                else
                    prev->next = current->next;

                delete current;
                count--;
                return;
            }
            prev = current;
            current = current->next;
        }
    }

    int size() const { return count; }

    ~HashMap()
    {
        for (int i = 0; i < capacity; i++)
        {
            Node* current = buckets[i];
            while (current != nullptr)
            {
                Node* temp = current;
                current = current->next;
                delete temp;
            }
        }
        delete[] buckets;
    }
};

// ────────────────────────────────────────────────────────────
//  VFSAdapter
//  Abd builds this. It wraps Assignment 3 VFS.
//  Everyone who needs to read/write files calls THIS,
//  not the VFS directly.
// ────────────────────────────────────────────────────────────

class VFSAdapter {
private:
    Directory* root;
    Directory* traversePath(const char* path);
    void getLastSegment(const char* path, char* dest);
    void getParentPath(const char* path, char* dest);
public:
    VFSAdapter();
    void      writeFile(const MyString& path, const MyString& data);
    MyString  readFile(const MyString& path);
    void      deleteDir(const MyString& path);
    void      createDir(const MyString& path);
    bool      exists(const MyString& path);
    ~VFSAdapter();
};

// ────────────────────────────────────────────────────────────
//  TestCase
//  Person 2 builds this. Simple data holder.
// ────────────────────────────────────────────────────────────

class TestCase {
private:
    MyString input;
    MyString expectedOutput;
public:
    TestCase();
    TestCase(const char* in, const char* expected);

    MyString getInput()    const;
    MyString getExpected() const;
};

// ────────────────────────────────────────────────────────────
//  Problem
//  Person 2 builds this.
// ────────────────────────────────────────────────────────────

class Problem : public Persistable {
private:
    int      id;
    MyString title;
    MyString description;
    int      difficulty;              // 1–5
    DynamicArray<TestCase> testCases;
public:
    Problem();
    Problem(int id, const char* title, const char* desc, int difficulty);

    void addTestCase(const TestCase& tc);

    int      getId()          const;
    MyString getTitle()       const;
    MyString getDescription() const;
    int      getDifficulty()  const;
    DynamicArray<TestCase>& getTestCases();

    void serialize(const char* path)   override;
    void deserialize(const char* path) override;
};

// ────────────────────────────────────────────────────────────
//  ProblemBank  —  Singleton
//  Person 2 builds this.
//  Call ProblemBank::getInstance() to access it anywhere.
// ────────────────────────────────────────────────────────────

class ProblemBank {
private:
    static ProblemBank*    instance;
    DynamicArray<Problem*> problems;
    ProblemBank();
public:
    static ProblemBank* getInstance();

    void                   loadFromVFS(VFSAdapter& vfs);
    void                   seedProblems();           // hardcode 15 problems here
    DynamicArray<Problem*> getByDifficulty(int level);
    DynamicArray<Problem*> getRandom(int count, int level);
    Problem*               getById(int id);

    ~ProblemBank();
};

// ────────────────────────────────────────────────────────────
//  User
//  Person 2 builds this.
// ────────────────────────────────────────────────────────────

class AppUser : public Persistable {
private:
    MyString username;
    MyString passwordHash;
    MyString email;
    bool     isVerified;
    MyString vfsHomePath;   // e.g. "/users/abd/"
public:
    AppUser();
    AppUser(const char* username, const char* email, const char* password);

    bool     registerUser(VFSAdapter& vfs);
    bool     verify(const char* token);
    bool     checkPassword(const char* password) const;
    void     deleteAccount(VFSAdapter& vfs);

    MyString getUsername()    const;
    MyString getEmail()       const;
    MyString getVfsHomePath() const;
    bool     getIsVerified()  const;

    void serialize(const char* path)   override;
    void deserialize(const char* path) override;
    static void setGlobalVFS(VFSAdapter* vfs);
};

// ────────────────────────────────────────────────────────────
//  Session
//  Person 2 builds this. Singleton-like usage.
//  Guards all contest/problem access.
// ────────────────────────────────────────────────────────────

class Session {
private:
    AppUser* currentUser;
    bool  loggedIn;
public:
    Session();

    void  login(AppUser* user);
    void  logout();
    AppUser* getUser()     const;
    bool  isActive()    const;
};

// ────────────────────────────────────────────────────────────
//  Submission
//  Abd builds this (used tightly with Judge and Contest).
// ────────────────────────────────────────────────────────────

class Submission {
private:
    MyString code;
    Verdict  verdict;
    int      attemptNumber;
    int      timeTakenSeconds;
    int      problemId;
public:
    Submission();
    Submission(const char* code, int problemId, int attempt, int timeTaken);

    MyString getCode()        const;
    Verdict  getVerdict()     const;
    int      getAttempt()     const;
    int      getTimeTaken()   const;
    int      getProblemId()   const;

    void setVerdict(Verdict v);
};

// ────────────────────────────────────────────────────────────
//  Judge
//  Abd builds this.
//  Takes a Submission + Problem, runs the code, returns verdict.
// ────────────────────────────────────────────────────────────

class Judge : public Evaluatable {
private:
    MyString tempDir;   // where temp files are written and deleted

    MyString injectTemplate(const MyString& userCode);
    bool     compile(const MyString& srcPath, const MyString& binPath);
    MyString runAndCapture(const MyString& binPath, const MyString& input);
    bool     compareOutput(const MyString& got, const MyString& expected);
    void     cleanup();
public:
    Judge();

    Verdict evaluate(Submission* s, Problem* p) override;
};

// ────────────────────────────────────────────────────────────
//  Contest  —  Abstract base class
//  Abd builds this + all three subclasses.
// ────────────────────────────────────────────────────────────

class Contest : public Persistable {
protected:
    DynamicArray<Problem*>    problemSet;
    DynamicArray<Submission*> submissions;
    int      timerSeconds;       // total allowed time
    int      startTimestamp;     // wall-clock time at start (from time())
    int      score;
    bool     isActive;
    MyString vfsSavePath;        // where mid-contest progress is saved
    AppUser*    owner;

    virtual void buildProblemSet(ProblemBank& bank) = 0;  // subclasses override this
    int      calcScore();
public:
    Contest();
    Contest(AppUser* user, int durationSeconds, const MyString& savePath);

    void    start(ProblemBank& bank);
    Verdict submit(const char* code, int problemId, int attempt);
    void    saveProgress(VFSAdapter& vfs);
    void    loadProgress(VFSAdapter& vfs);
    void    endContest(VFSAdapter& vfs);

    int     getTimeRemaining()  const;   // wall clock - startTimestamp
    int     getScore()          const;
    bool    getIsActive()       const;
    DynamicArray<Submission*>& getSubmissions();

    void serialize(const char* path)   override;
    void deserialize(const char* path) override;

    virtual ~Contest();
};

// ────────────────────────────────────────────────────────────
//  Contest subclasses
//  Abd builds these. Only override buildProblemSet().
// ────────────────────────────────────────────────────────────

class EasyContest : public Contest {
protected:
    void buildProblemSet(ProblemBank& bank) override;
    // picks difficulty 1–2 problems
public:
    EasyContest(AppUser* user, VFSAdapter& vfs);
};

class MediumContest : public Contest {
protected:
    void buildProblemSet(ProblemBank& bank) override;
    // picks difficulty 3 problems
public:
    MediumContest(AppUser* user, VFSAdapter& vfs);
};

class HardContest : public Contest {
protected:
    void buildProblemSet(ProblemBank& bank) override;
    // picks difficulty 4–5 problems
public:
    HardContest(AppUser* user, VFSAdapter& vfs);
};

#endif // SHARED_INTERFACES_H